import os, xbmc, xbmcaddon

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = 'KOVOO SYSTEMASSISTENT'
EXCLUDES       = [ADDON_ID, 'repository.supremebuilds']
# Text File with build info in it.
BUILDFILE      = 'http://kovoo.sk/newwiz/txt/royalbuilds.txt'
# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.
APKFILE        = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/txt/streaming.txt'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = 'KoVoo auf YouTube'
YOUTUBEFILE    = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/txt/youtube.txt'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/txt/addons.txt'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = 'https://wizard.supremebuilds.com/texts/advanced.txt'

# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/builds.png'
ICONMAINT      = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/wartung.png'
ICONAPK        = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/apps.png'
ICONADDONS     = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/addons.png'
ICONYOUTUBE    = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/youtube.png'
ICONSAVE       = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/daten.png'
ICONTRAKT      = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/trakt.png'
ICONREAL       = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/debrid.png'
ICONLOGIN      = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/login.png'
ICONCONTACT    = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/kontakt.png'
ICONSETTINGS   = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/system.png'
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '='

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'red'
COLOR2         = 'royalblue'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = 'Fuer Support und aktuelle Updates besucht uns um Forum:\r\n\r\nhttps://kovoo.info/\r\n\r\nNehmt zur Kenntnis, dass es viele Gruppen gibt die uns kopieren. Fuer eine virenfreies Setup empfehlen wir, unsere Builds immer aus unserem Forum oder anderen,von uns verifizierten Quellen, zu beziehen.\r\n\r\nWir bedanken uns herzlich bei unseren Supporten! Ihr tragt dazu bei, dass wir KoVoo stehts verbessern und so noch besser machen.'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/contactus.png'
CONTACTFANART  = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/contactfan.jpg'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'Yes'
# Url to wizard version
WIZARDFILE     = ''
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'No'
# Addon ID for the repository
REPOID         = 'repository.supremebuilds'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'https://raw.githubusercontent.com/kodiskills/supremebuildsrepo/master/repository.supremebuilds/addon.xml'
# Url to folder zip is located in
REPOZIPURL     = 'https://github.com/kodiskills/supremebuildsrepo/raw/master/zips'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/txt/notify.txt'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
HEADERMESSAGE  = 'KOVOO SYSTEMASSISTENT'
# url to image if using Image 424x180
HEADERIMAGE    = 'http://oirteujzo8ipertuzo8iertuzoiertzoijoighiurfedshtiguwe.de/final/wizard/pix/notify.png'
# Background for Notification Window
BACKGROUND     = ''
#########################################################
