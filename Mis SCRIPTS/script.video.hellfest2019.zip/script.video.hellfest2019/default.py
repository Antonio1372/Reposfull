# -*- coding: utf-8 -*- 
import xbmc
import xbmcgui
url = "https://arteevent01-lh.akamaihd.net/i/arte_event01@395110/master.m3u8"
listitem = xbmcgui.ListItem("Hellfest 2019")
listitem.setInfo('video', {'Title': 'Hellfest 2019', 'Genre': 'Live Stream'})
xbmc.Player().play(url, listitem)


