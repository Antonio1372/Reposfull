# -*- coding: utf-8 -*- 
import xbmc
import xbmcgui
url = "https://arteevent02-lh.akamaihd.net/i/arte_event02@308866/index_3_av-p.m3u8?sd=10&rebase=on"
listitem = xbmcgui.ListItem("Southside 2019")
listitem.setInfo('video', {'Title': 'Southside 2019', 'Genre': 'Live Stream'})
xbmc.Player().play(url, listitem)


