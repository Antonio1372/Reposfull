import xbmc
from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules.colors import GetColorHex

#updated to single service

class XmlEpg(object):

	started     = False
	completed   = False

	def __init__(self):
		self.loadtype = int(setting('getepgdata'))
		self.Epgs     = ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']
		self.MyEpgList  = self.MyEpgList()


	def XMLTvConstruct(self):
		if setting_true('service.enabled') and self.loadtype == 0:
			if setting_true('clear_all_epg_data'):
				if PathExists(epg_folder):
					DelAllContents(epg_folder)
				setting_set('clear_all_epg_data','false')
			CreateDir(epg_folder)
			self.started = True
			from resources.lib.modules import epg_source
			epg_source.GetServiceXmlTv()
			for Epg in self.MyEpgList:
				country = Epg.lower().replace('epg','').strip()
				CreateDir(eval('{}_epg_folder'.format(country.lower())))
				updated = epg_source.CustomXMLTV(epg_country=country)
				if updated:
					Notify(message='{} EPG Modified'.format(country.upper()))
				else:
					Notify(message='{} is EPG up to date'.format(country.upper()))
			else:
				self.completed = True
		else:
			self.CloseService()

	def CloseService(self,msg='Closing service script'):
		Log(msg)
		import sys
		sys.exit()

	def DelEpgFiles(self):
		DelAllContents(epg_folder)

	def MyEpgList(self):
		i = list()
		for Epg in self.Epgs:
			if setting_true('{}'.format(Epg)):
				i.append(Epg)
		return i 

class SubCheck(object):
	# to imporove loading time after 1st run and when backing in and out addon,Also to use for notifiy when sub is near renewal 
	def __init__(self):
		if setting_true('service.enabled'): 
			if dbTableExists(DATABASE,'subinfo'):
				if len(dbReadCol(DATABASE,'subinfo','next_check_dt')) >0:
					td = dbReadAll(DATABASE,'subinfo')
					for row in td:
						nc_dt = DateTimeStrp(row[2],'%Y-%m-%d %H:%M:%S')
						if DateTimeNow().replace(microsecond=0) > nc_dt:
							dbDeleteTableContent(DATABASE,'subinfo')
							if not len(dbReadRows(DATABASE,'subinfo')) > 0:
								det = self.GetSubInfo()
								dbWrite(DATABASE,'subinfo',(det[0],det[1],det[2],0,0))
				else:
					det = self.GetSubInfo()
					dbWrite(DATABASE,'subinfo',(det[0],det[1],det[2],0,0))
			else:
				dbCreateTableHeaders(DATABASE,'subinfo','exp_dt TIMESTAMP,login INTEGER,next_check_dt TIMESTAMP,exp_notice_days INTEGER,exp_notice_hours INTEGER')
				if setting_true('service.enabled'):
					det = self.GetSubInfo()
					dbWrite(DATABASE,'subinfo',(det[0],det[1],det[2],0,0))
		else:
			pass

	def GetSubInfo(self):
		logincheck = 0
		SubInfo = list()
		nc = DateTimeDelta(DateTimeNow().replace(microsecond=0),h=24)
		from resources.lib.modules import panelcalls
		if panelcalls.CheckAccount():
			logincheck = 1
			ui = panelcalls.GetEpg().get('user_info')
			xd = FromTimeStamp(float(ui.get('exp_date')))
			SubInfo.extend([xd,logincheck,nc])
		else:
			SubInfo.extend([None,logincheck,nc])
		return SubInfo

class SubExpireNotice(object):

	def __init__(self):
		self.exp_dates = self.GetSubExpire()
		self.days = self.ConvertSetting_day()
		self.hours = self.ConvertSetting_hrs()
		self.tonotify = self.CheckSubExpire()
		if len(self.tonotify)>0:
			self.msg = self.AlertMsg()
			self._Window()

	def AlertMsg(self):
		lines = list()
		for d in self.tonotify:
			t=d.get('timeleft')
			if isinstance(t,timedelta):
				D,H,M,S = ConvertTimeDelta(t)
				if D != 0:
					D = '{} Days'.format(D) if D >= 2 else '{} Day'.format(D)
				else:
					D = ''
				if H != 0:
					H = '{} Hours'.format(H) if H >= 2 else '{} Hour'.format(H)
				else:
					H = ''
				line = 'Universal Sub Expires in {} {}'.format(D,H)
				lines.append(line)
		if len(lines) >1:
			msg = '\n'.join(lines)
		else:
			msg = lines[0]
		return msg

	def CheckSubExpire(self):
		nl = list()
		dtn = DateTimeNow().replace(microsecond=0)
		for items in self.exp_dates:
			exdate = items[0]
			if exdate !=None:
				if int(dbReadCol(DATABASE,'subinfo','exp_notice_days')[0][0]) == 0:
					if dtn > DateTimeDelta(DateTimeStrp(exdate,'%Y-%m-%d %H:%M:%S'),d = -self.days):
						nl.append({'timeleft':DateTimeStrp(exdate,'%Y-%m-%d %H:%M:%S')-dtn,'dbrow':'exp_notice_days'})
						continue 
				elif int(dbReadColMatch(DATABASE,'subinfo','service','exp_notice_hours',ser)) == 0:
					if dtn > DateTimeDelta(DateTimeStrp(exdate,'%Y-%m-%d %H:%M:%S'),h = -self.hours):
						nl.append({'timeleft':DateTimeStrp(exdate,'%Y-%m-%d %H:%M:%S')-dtn,'dbrow':'exp_notice_hours'})
				elif dtn > DateTimeStrp(exdate,'%Y-%m-%d %H:%M:%S'):
					nl.append({'timeleft':0,'dbrow':None})
		return nl
	
	def ConvertSetting_day(self):
		i = int(setting('subexpirewarnday'))
		if i==0:
			d = 28
		elif i==1:
			d=14
		elif i==2:
			d=7
		elif i==3:
			d=3
		elif i==4:
			d=1
		else:
			d=0
		return d

	def ConvertSetting_hrs(self):
		i = int(setting('subexpirewarnhrs'))
		if i==0:
			h=12
		elif i==1:
			h=24
		elif i==2:
			h=48
		elif i==3:
			h=72
		else:
			h=0	
		return h

	def GetSubExpire(self):
		if dbTableExists(DATABASE,'subinfo'):
			info = dbReadCol(DATABASE,'subinfo','exp_dt')
		else:
			info = list()
		return info

	def _Window(self):
		from resources.lib.gui import dialog_action
		d=dialog_action.Dialog_Action(label='Service Expiring Soon',msg=self.msg,buttons=('ok','remind'),color=GetColorHex('lime'))
		d.doModal()
		if d.button_ok:
			Log('OK pressed')
			self.UpdateNotice()
		elif d.button_remind:
			Log('Remind pressed')
		del d

	def UpdateNotice(self):
		for d in self.tonotify:
			ser = d.get('service')
			col = d.get('dbrow')
			dbUpdate(DATABASE,'subinfo',col,1)


if __name__ == '__main__':
	SubCheck()
	SubExpireNotice()
	xmlepg = XmlEpg()
	xmlepg.XMLTvConstruct()
	monitor = xbmc.Monitor()
	while  not xmlepg.completed:
		if monitor.abortRequested():
			xmlepg.DelEpgFiles()
			xmlepg.CloseService('xbmc.monitor stopped service script')
