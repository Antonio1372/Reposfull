# -*- coding: utf-8 -*-
import xbmcgui
from resources.lib.modules._addon import *
from resources.lib.modules._common import *

class QuickLinks(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM       = 7
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100
	ACTION_MOUSE_RIGHT_CLICK = 101
	ACTION_MOUSE_LONG_CLICK  = 108
	ACTION_CONTEXT_MENU      = 117

	BUTTON_BACK = 1000

	FADE_BOTTOM = 3003
	FADE_LEFT   = 3000
	FADE_RIGHT  = 3001 
	FADE_TOP    = 3002

	def __new__(cls):
		return super(QuickLinks, cls).__new__(cls, 'Service_Dir.xml', addon_path)

	def __init__(self):
		Log('opening quicklinks window')
		super(QuickLinks,self).__init__()
		self.db        = DATABASE
		self.dbtable   = 'quicklinks'
		self.data      = dbReadAll(self.db,self.dbtable)
		self.COLOR     = 'purple'
		self.FADE_LIST = []

	def onInit(self):
		self.setFadeVisable()
		self.setProperty('COLOR',self.COLOR)
		self.control_list = self.getControl(2000)
		if not self.control_list.size() > 0:
			for item in self.data:
				label  = item[0]
				url    = item[1]
				mode   = item[2]
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
				ItemList = xbmcgui.ListItem(label,path=url)
				self.control_list.addItem(ItemList)
		self.setFocusId(2000)

	def onAction(self,action):
		Log('Action: {}'.format(action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 2000:
				PosID = self.control_list.getSelectedPosition()
				label = self.data[PosID][0]
				url = self.data[PosID][1]
				mode = self.data[PosID][2]
				RunModule(url=url,mode=mode,name=label)
		elif action == self.ACTION_NAV_BACK:
			self.Close()
		elif action in [self.ACTION_MOUSE_RIGHT_CLICK,self.ACTION_MOUSE_LONG_CLICK,self.ACTION_CONTEXT_MENU]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus {} Pos {}'.format(ActionID,PosID))
			if ActionID == 2000:
				PosID = self.control_list.getSelectedPosition()
				label = self.data[PosID][0]
				url = self.data[PosID][1]
				mode = self.data[PosID][2]
				u=CreateModule(url=url,mode=mode,name=label)
				item_list = [('[I]Remove[/I]',u,4),('[I]Rename[/I]',u,5)]
				if mode == 3:
					item_list.append(('[I]Play[/I]',u,2))
				from resources.lib.gui import context_menu
				d=context_menu.ContextMenu(item_list=item_list,caller='quicklinks')
				d.doModal()
				if d.ReloadList:
					if d.ListRemove:
						self.RemoveList(PosID)
					elif d.ListUpdate:
						self.UpdateList()
				del d 
	def setControlVisible(self, controlId, visible):
		if not controlId:
			return
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.BUTTON_BACK:
			self.Close()

	def RemoveList(self,itemPosition):
		self.control_list = self.getControl(2000)
		self.control_list.removeItem(itemPosition)

	def UpdateList(self):
		self.control_list = self.getControl(2000)
		self.control_list.reset()
		self.data = dbReadAll(self.db,self.dbtable)
		for item in self.data:
			label  = item[0]
			url    = item[1]
			mode   = item[2]
			icon   = item[3]
			url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
			ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
			self.control_list.addItem(ItemList)
		self.setFocusId(2000) 



	def Close(self,msg='Closing Quicklinks'):
		Log(msg)
		super(QuickLinks,self).close()

	def setFadeVisable(self):
		#used to darken the screen on a side 
		FADES = [self.FADE_BOTTOM,self.FADE_LEFT,self.FADE_RIGHT,self.FADE_TOP]
		SHOW = []
		for f in self.FADE_LIST:
			SHOW.append(eval('self.FADE_{}'.format(f.upper())))
		HIDE = list(set(FADES)-set(SHOW))
		for s in SHOW:
			self.setControlVisible(s,True)
		for h in HIDE:
			self.setControlVisible(h,False)	

