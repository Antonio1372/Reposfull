import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules import panelcalls
from resources.lib.modules.colors import GetColorHex

class Dir_Service(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM       = 7
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100
	ACTION_MOUSE_RIGHT_CLICK = 101
	ACTION_MOUSE_LONG_CLICK  = 108
	ACTION_CONTEXT_MENU      = 117

	BACK                    = 1000

	LIST_TEXT_LARGE = 2000
	LIST_TEXT_SMALL = 2002

	FADE_BOTTOM = 3003
	FADE_LEFT   = 3000
	FADE_RIGHT  = 3001 
	FADE_TOP    = 3002

	def __new__(cls,itemlist,color,fontsize='large',fade=[]):
		return super(Dir_Service, cls).__new__(cls, 'Service_Dir.xml', addon_path)

	def __init__(self,itemlist,color,fontsize='large',fade=[]):
		#fade sent as list variables = 'top','bottom','left','right'
		super(Dir_Service,self).__init__()
		self.LISTITEM = itemlist
		self.FADE_LIST = fade
		self.COLOR = color
		self.FONTSIZE = fontsize


	def onInit(self):
		self.setProperty('COLOR',self.COLOR)
		self.setFadeVisable()
		if self.FONTSIZE== 'large':
			self.setControlVisible(self.LIST_TEXT_SMALL,False)
			self.control_list = self.getControl(self.LIST_TEXT_LARGE)
			if self.control_list.size() > 0:
				self.Reset(self.LIST_TEXT_LARGE)
			for item in self.LISTITEM:
				ItemList = xbmcgui.ListItem(item[0])
				ItemList.setProperty('mode',str(item[1]))
				ItemList.setProperty('variable',item[2])
				self.control_list.addItem(ItemList)
			self.setFocusId(self.LIST_TEXT_LARGE)
		elif self.FONTSIZE == 'small':
			self.setControlVisible(self.LIST_TEXT_LARGE,False)
			self.control_list = self.getControl(self.LIST_TEXT_SMALL)
			if self.control_list.size() > 0:
				self.Reset(self.LIST_TEXT_SMALL)
			for item in self.LISTITEM:
				ItemList = xbmcgui.ListItem(item[0])
				ItemList.setProperty('mode',str(item[1]))
				ItemList.setProperty('variable',item[2])
				self.control_list.addItem(ItemList)
			self.setFocusId(self.LIST_TEXT_SMALL)


	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus {} Pos {}'.format(ActionID,PosID))
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				label = self.control_list.getListItem(int(gsp)).getLabel()
				mode = int(self.control_list.getListItem(int(gsp)).getProperty('mode'))
				variable = self.control_list.getListItem(int(gsp)).getProperty('variable')
				RunModule(mode=mode,name=label,url=variable)
		elif action == self.ACTION_NAV_BACK:
			self.Close()
		elif action in [self.ACTION_MOUSE_RIGHT_CLICK,self.ACTION_MOUSE_LONG_CLICK,self.ACTION_CONTEXT_MENU]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				label = self.control_list.getListItem(int(gsp)).getLabel()
				mode = int(self.control_list.getListItem(int(gsp)).getProperty('mode'))
				variable = self.control_list.getListItem(int(gsp)).getProperty('variable')
				u=CreateModule(mode=mode,name=label,url=variable)
				item_list = [('[I]Add to Favourites[/I]',u,0),('[I]Add to QuickLink[/I]',u,1)]
				if HasAddon('plugin.program.super.favourites'):
					item_list.append(('[I]Add to Super Favourites[/I]',u,3))
				from resources.lib.gui import context_menu
				d=context_menu.ContextMenu(item_list)
				d.doModal()
				del d 

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.BACK:
			self.Close()

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()	

	def Close(self,msg='Dir_Service closing'):
		Log(msg)
		self.close()
		
	def setControlVisible(self, controlId, visible):
		if not controlId:
			return
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)	

	def setFadeVisable(self):
		#used to darken the screen on a side 
		FADES = [self.FADE_BOTTOM,self.FADE_LEFT,self.FADE_RIGHT,self.FADE_TOP]
		SHOW = []
		for f in self.FADE_LIST:
			SHOW.append(eval('self.FADE_{}'.format(f.upper())))
		HIDE = list(set(FADES)-set(SHOW))
		for s in SHOW:
			self.setControlVisible(s,True)
		for h in HIDE:
			self.setControlVisible(h,False)	


def LiveTvCat():
	#list return label,mode,variable
	LISTITEM = panelcalls.GetLiveCat()
	d=Dir_Service(LISTITEM,GetColorHex('purple'))
	d.doModal()
	del d


def EpgDir():
	item_list = []
	for Epg in ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']:
		if setting_true(Epg):
			name = Epg.replace('Epg','').strip().upper()
			label = ReplaceMulti(name,epg_short_long_name)
			item_list.append((label,10,name))
	d=Dir_Service(item_list,GetColorHex('purple'))
	d.doModal()
	del d

def OnDemandCat():
	LISTITEM = panelcalls.GetVodCat()
	d=Dir_Service(LISTITEM,GetColorHex('purple'))
	d.doModal()
	del d
