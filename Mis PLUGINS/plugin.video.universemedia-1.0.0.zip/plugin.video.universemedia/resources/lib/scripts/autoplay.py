# -*- coding: utf-8 -*-
import sqlite3
import xbmc
import xbmcaddon
import xbmcgui
import sys
import os


class AutoPlay(object):
	def __init__(self):
		self.addon         = xbmcaddon.Addon('plugin.video.universemedia')
		self.addoninfo     = self.addon.getAddonInfo
		self.setting       = self.addon.getSetting
		self.setting_set   = self.addon.setSetting
		self.addon_profile = xbmc.translatePath(self.addoninfo('profile').decode('utf-8'))
		self.epg_folder    = os.path.join(self.addon_profile,'epg')
		self.uk_epg_folder = os.path.join(self.epg_folder,'uk_epg')
		self.us_epg_folder = os.path.join(self.epg_folder,'us_epg')
		self.es_epg_folder = os.path.join(self.epg_folder,'es_epg')
		self.de_epg_folder = os.path.join(self.epg_folder,'de_epg')
		self.my_epg_folder = os.path.join(self.epg_folder,'my_epg')
		self.hk_epg_folder = os.path.join(self.epg_folder,'hk_epg')
		self.UK_SOURCE_DB  = os.path.join(self.uk_epg_folder,'source.db')
		self.US_SOURCE_DB  = os.path.join(self.us_epg_folder,'source.db')
		self.ES_SOURCE_DB  = os.path.join(self.es_epg_folder,'source.db')
		self.DE_SOURCE_DB  = os.path.join(self.de_epg_folder,'source.db')
		self.MY_SOURCE_DB  = os.path.join(self.my_epg_folder,'source.db')
		self.HK_SOURCE_DB  = os.path.join(self.hk_epg_folder,'source.db')
		self.Mode          = int(sys.argv[1])
		self.Channel       = sys.argv[2]
		self.Start         = sys.argv[3]
		try:
			self.EpgCountry= sys.argv[4] 
		except IndexError:
			self.EpgCountry= ''
		self.player        = xbmc.Player()
		self._RunMode(self.Mode)

	def _RunMode(self,Mode):
		if Mode==1:
			self.AutoPlay_Start(self.Channel,self.Start,self.EpgCountry)
		elif Mode==2:
			self.AutoPlay_Stop(self.Channel,self.Start)
		else:
			self.Log('Mode not correct {}'.format(Mode))

	def AutoPlay_Start(self,Channel,Start,EpgCountry):
		db_path = eval('self.{}_SOURCE_DB'.format(EpgCountry.upper()))
		try:
		    conn = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
		except Exception as detail:
		    self.Log("EXCEPTION: {}".format(detail))
		c = conn.cursor()
		c.execute('SELECT stream_url FROM custom_stream_url WHERE channel=?', (Channel,))
		row = c.fetchone()
		if not row :
		    c.execute('SELECT stream_url FROM channels WHERE id=?',(Channel,))
		    row = c.fetchone()
		if row:
			url = row[0]
			self.setting_set('playing.channel',Channel)
			self.setting_set('playing.start',Start)
			self.StreamPlay(Channel,url)

	def AutoPlay_Stop(self,Channel,Start):
		if self.player.isPlaying():
			if self.setting('playing.channel') != channel:
				self.Close(msg='AutoPlay Channel({}) not playing'.format(Channel))
			elif self.setting('playing.start') != start:
				self.Close(msg='AutoPlay Program not playing')
			self.setting_set('playing.channel','')
			self.setting_set('playing.start','')
			self.player.stop()
		else:
			self.Close(msg='Player not playing')


	def StreamPlay(self,label,url):
		listitem = xbmcgui.ListItem( label = label, path=url )
		self.player.play(url,listitem)

	def Close(self,msg='Closing Script'):
		self.Log(msg)
		sys.exit()

	def Log(self,msg):
		if self.setting_true('debug'):
			from inspect import getframeinfo, stack
			fileinfo = getframeinfo(stack()[1][0])
			xbmc.log('*__{}__{}*{} Python file name = {} Line Number = {}'.format(self.addoninfo('name'),self.addoninfo('verison'),msg,fileinfo.filename,fileinfo.lineno), level=xbmc.LOGNOTICE)
		else:pass

if __name__ == '__main__':
	AutoPlay()