# -*- coding: utf-8 -*-
import datetime
import dateutil.parser as dparser
import difflib
import inspect 
import re
import requests
import time
import urllib
import xbmc
import xbmcgui
import xbmcplugin 
import xbmcvfs
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from resources.lib.modules import panelcalls
from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules.colors import GetColorHex

Settings = ['username','password']
Epgs     = ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']
pDialog = xbmcgui.DialogProgress()
guiDialog = xbmcgui.Dialog()


class FileWrapper(object):
	def __init__(self, filename):
		self.vfsfile = xbmcvfs.File(filename,"rb")
		self.size = self.vfsfile.size()
		self.bytesRead = 0

	def close(self):
		self.vfsfile.close()

	def read(self, byteCount):
		self.bytesRead += byteCount
		return self.vfsfile.read(byteCount)

	def tell(self):
		return self.bytesRead


def MyEpgList():
	i = list()
	for Epg in Epgs:
		if setting_true('{}'.format(Epg)):
			i.append(Epg)
	return i 

def ServiceSet():
	if dbTableExists(DATABASE,'subinfo'):
		if dbReadCol(DATABASE,'subinfo','login') == 1:
			if not setting_true('service.enabled'):
				setting_set('service.enabled','true')
	elif panelcalls.CheckAccount():
		if not setting_true('service.enabled'):
			setting_set('service.enabled','true')
	else:
		if setting_true('service.enabled'):
			setting_set('service.enabled','false')

def ServiceLoad():
	if not setting_true('service.enabled') and setting('service.username') == '' and setting('service.password') == '':
		OpenSettings()
	else:
		ServiceSet()
		EpgList = MyEpgList()
		p = 100.00/len(EpgList)*2 if len(EpgList)>0  else 1
		c = 0
		if SystemBuild() >= 18:
			xbmc.executebuiltin('Dialog.Close(busydialog)')
		if int(setting('getepgdata')) == 1:
			pDialog.create('Loading EPG Files')
			CreateDir(epg_folder)
			from resources.lib.modules import epg_source
			c+=1
			epg_source.GetServiceXmlTv(Service)
			pDialog.update(c*int(p),line1='Getting EPG')
			for Epg in EpgList:
				c+=1
				country = Epg.lower().replace('epg','').strip()
				pDialog.update(c*int(p),line3='Path {}'.format(eval('{}_epg_folder'.format(country.lower()))))
				CreateDir(eval('{}_epg_folder'.format(country.lower())))
				pDialog.update(c*int(p),line2='Creating Custom Guide for {}'.format(country.upper()),line3='Path {}'.format(eval('{}_EPG_XML'.format(country.upper()))).replace(USERDATA,''))
				epg_source.CustomXMLTV(epg_country=country)
			pDialog.close()
		from resources.lib.gui import home_service
		d=home_service.Home_Service()
		d.doModal()
		del d
	
def PreLoadActions():
	if setting_true('clear_all_epg_data') and int(setting('getepgdata')) == 1:
		DelAllContents(epg_folder)
		setting_set('clear_all_epg_data','false')
	if len(sys.argv) > 1:
		category = sys.argv[1]
		if category:
			setting_set('category',category)
	channel = ""
	if len(sys.argv) > 3:
		channel = sys.argv[3]
	setting_set('channel.arg',channel)
	CopyFile(actionsjs,profile_actionsjs)
	if not xbmcvfs.exists(epg_folder):
		xbmcvfs.mkdir(epg_folder)

def SearchVod(service_name):
	vodlist = GetSearchVodList(service_name)
	d=Menu_Vod('Vod_Menu.xml',addon_path,item_list=vodlist,service_name=service_name)
	d.doModal()
	del d




def StreamPlay(label,url):
	player = XbmcPlayer()
	listitem = xbmcgui.ListItem( label = label, path=url )
	player.play(url,listitem)

			
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
except:
	pass
try:
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
except:
	pass
try:
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
except:
	pass
try:
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
except:
	pass

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
Log(params)

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:        
		mode=int(params["mode"])
except:
		pass
try:        
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:        
		description=urllib.unquote_plus(params["description"])
except:
		pass


if mode==None:
	if setting_true('toolstart'):
		if SystemBuild() >= 18:
			xbmc.executebuiltin('Dialog.Close(busydialog)')
		from resources.lib.gui import dir_tools
		d=dir_tools.MainMenu()
		d.doModal()
		del d
	else:
		Log('excuting pre load actions')
		PreLoadActions()
		Log('Checking and setting MyServices')
		ServiceLoad()
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==1:
	Log('Opening LiveTvList')
	from resources.lib.gui import dir_service
	dir_service.LiveTvCat()
elif mode==2:
	Log('Opening Menu_Live')
	from resources.lib.gui import menu_live
	menu_live.MenuLive(name,url)
elif mode==3:
	Log('Playing {} {}'.format(name,url))
	StreamPlay(name,url)
elif mode==4:
	Log('Opening account info')
	AccountInfo(url)
elif mode==5:
	Log('OpenSettings')
	OpenSettings()
elif mode==6:
	Log('Getting VOD cats')
	from resources.lib.gui import dir_service
	dir_service.OnDemandCat()
elif mode==7:
	Log('Vod lists menu')
	from resources.lib.gui import vod_menu
	vod_menu.MenuVod(name,url)
elif mode==8:
	Log('searching vod url {} mode {}'.format(url,mode))
	from resources.lib.gui import vod_menu
	vod_menu.SearchVod()
elif mode==9:
	Log('Open EPG menu {} {} {} {}'.format(name,url,mode,description))
	from resources.lib.gui import dir_service
	dir_service.EpgDir()
elif mode==10:
	Log('Opening EPG name={},url={},mode={}'.format(name,mode,url))
	import tvguide
	w=tvguide.TVGuide(url)
	w.doModal()
	del w
xbmcplugin.endOfDirectory(int(sys.argv[1]))
