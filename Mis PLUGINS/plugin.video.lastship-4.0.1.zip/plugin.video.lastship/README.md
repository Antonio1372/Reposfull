![Lastship icon](https://raw.githubusercontent.com/lastship/plugin.video.lastship/nightly/icon.png)


## Willkommen bei Lastship für Kodi!

Bei Lastship handelt es sich um ein Video-Addon für Kodi, welches das Streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht

Der Funktionsumfang von Lastship wird von den beteiligten Entwicklern stetig weiterentwickelt 

Webseiten werden auch als Indexseiten bezeichnet, welche auf die eigentlichen Quellen verweisen, die für das bereitgestellte Angebot verantworlich sind! 

Lastship dient nur als Suchmaschine und hostet selbst keine Dateien


[![Join the chat at https://gitter.im/Lastship_Chat/Lobby](https://badges.gitter.im/Lastship_Chat/Lobby.svg)](https://gitter.im/Lastship_Chat/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
