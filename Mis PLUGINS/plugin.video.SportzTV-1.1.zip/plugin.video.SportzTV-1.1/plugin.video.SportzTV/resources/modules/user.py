import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlNwb3J0elRW')

name = b.b64decode('U3BvcnR6IFRW')

host = b.b64decode('aHR0cDovL2xvZ2ludG8udHY=')

port = b.b64decode('ODM=')