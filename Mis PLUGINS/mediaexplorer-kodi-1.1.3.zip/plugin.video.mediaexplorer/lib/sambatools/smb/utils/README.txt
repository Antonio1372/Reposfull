
md4.py and U32.py
Both modules downloaded from http://www.oocities.org/rozmanov/python/md4.html.
Licensed under LGPL

pyDes.py 2.0.0
Downloaded from http://twhiteman.netfirms.com/des.html
Licensed under public domain

sha256.py
Downloaded from http://xbmc-addons.googlecode.com/svn-history/r1686/trunk/scripts/OpenSubtitles_OSD/resources/lib/sha256.py
Licensed under MIT
