# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    if "Page not found" in data or "File was deleted" in data or "404 Not Found" in data:
        return ResolveError(0)

    sources = scrapertools.find_single_match(data, 'sources: (\[.*?\]+)')
    for url, res in scrapertools.find_multiple_matches(sources, 'file:"([^"]+)",label:"([^"]+)"'):  
        itemlist.append(Video(url=url, res=res))

    return itemlist
