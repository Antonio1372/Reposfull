# -*- coding: utf-8 -*-

from libs.tools import *


dict_deportes = {
    'SOCCER': {
        'max': 120,
        'icon': os.path.join(image_path, 'soccer.png'),
        'label': 'Futbol',
        'competitions': {
            'SPANISH LA LIGA':{
              'label': 'La Liga',
              'icon': os.path.join(image_path, 'soccer_liga_espana.png'),
            },
            'SPANISH LEAGUE':{
              'label': 'La Liga',
              'icon': os.path.join(image_path, 'soccer_liga_espana.png'),
            },
            'SPANISH LA LIGA 2':{
              'label': 'La Liga 123',
              'icon': os.path.join(image_path, 'socccer_liga_123.png'),
            },
            'SPANISH LEAGUE 2':{
              'label': 'La Liga 123',
              'icon': os.path.join(image_path, 'socccer_liga_123.png'),
            },
            'COPA DEL REY':{
              'label': 'Copa del Rey',
              'icon': os.path.join(image_path, 'soccer_copa_del_rey.png'),
            },
            'UEFA CHAMPIONS LEAGUE':{
              'label': 'Liga de Campeones de la UEFA',
              'icon': os.path.join(image_path, 'soccer_champions_league.png'),
            },
            'UEFA EUROPA LEAGUE':{
              'label': 'Liga Europa de la UEFA',
              'icon': os.path.join(image_path, 'soccer_europa_league.png'),
            },
            'COPA IBERICA':{
              'label': 'Copa Iberica',
              'icon': os.path.join(image_path, 'copa_iberica.png'),
            },
            'INTERNATIONAL CHAMPIONS CUP':{
              'label': 'International Champions Cup',
              'icon': os.path.join(image_path, 'International_Champions_Cup.png'),
            },
            'PREMIER LEAGUE':{
              'label': 'Premier League',
              'icon': os.path.join(image_path, 'soccer_liga_inlaterra.png'),
            },
            'FRANCE LIGUE 1':{
              'label': 'Francia Ligue 1',
              'icon': os.path.join(image_path, 'soccer_liga_francia.png'),
            },
            'BUNDESLIGA':{
              'label': 'Bundesliga',
              'icon': os.path.join(image_path, 'soccer_liga_alemana.png'),
            },
            'MEXICO LIGA MX':{
              'label': 'Primera División de México',
              'icon': os.path.join(image_path, 'soccer_liga_mexico.png'),
            },
            'USA MLS':{
              'label': 'Major League Soccer',
              'icon': os.path.join(image_path, 'soccer_liga_usa.png'),
            },
            'CHILE PRIMERA':{
              'label': 'Primera División de Chile',
              'icon': os.path.join(image_path, 'soccer_liga_chile.png'),
            },
            'ARGENTINA SUPERLIGA':{
              'label': 'Primera División de Argentina',
              'icon': os.path.join(image_path, 'soccer_liga_argentina.png'),
            },
            'DUTCH SUPERCUP':{
              'label': 'Supercopa de los Países Bajos',
              'icon': os.path.join(image_path, 'soccer_dutch_cup.png'),
            },
            'FRIENDLY MATCH':{
              'label': 'Amistoso',
              'icon': os.path.join(image_path, 'soccer_amistoso.png'),
            }
        }
    },
    'TENNIS': {
        'max': 180,
        'icon': os.path.join(image_path, 'tennis.png'),
        'label': 'Tenis'
    },
    'MOTOGP': {
        'max': 180,
        'icon': os.path.join(image_path, 'motogp.png'),
        'label': 'Moto GP'
    },
    'FORMULA 1': {
        'max': 180,
        'icon': os.path.join(image_path, 'formula_1.png'),
    },
    'RUGBY': {
        'max': 180,
        'icon': os.path.join(image_path, 'rugby.png'),
    },
    'MMA': {
        'max': 120,
        'icon': os.path.join(image_path, 'mma.png'),
        'label': 'Lucha'
    },
    'BOXING': {
        'max': 120,
        'icon': os.path.join(image_path, 'boxeo.png'),
        'label': 'Boxeo'
    },
    'BASKETBALL': {
        'max': 90,
        'icon': os.path.join(image_path, 'basketball.png'),
        'label': 'Baloncesto'
    },
    'CYCLING': {
        'max': 180,
        'icon': os.path.join(image_path, 'ciclismo.png'),
        'label': 'Ciclismo'
    },
    'FORMULA1': {
        'max': 180,
        'icon': os.path.join(image_path, 'formula_1.png'),
        'label': 'Formula 1'
    }
}


def date_to_local(fecha, hora, formatTime='UTC'):
    def get_utc_offset():
        utc_offset = xbmcgui.Window(10000).getProperty('utc_offset')
        if not utc_offset:
            data = urllib2.urlopen(urllib2.Request('https://time.is/es/UTC', headers=headers)).read()
            utc = re.findall('<div id="twd">(\d+):', data, re.DOTALL)[0]
            cest = re.findall('<span id="favt4">(\d+):', data, re.DOTALL)[0]
            utc_offset = str(int(cest) - int(utc))
            xbmcgui.Window(10000).setProperty('utc_offset', utc_offset)

        return int(utc_offset)

    aux = re.findall('(\d{1,2}/\d{1,2}/)(\d{2})$', fecha)
    if aux:
        fecha = aux[0][0] + '20' + aux[0][1]

    if formatTime == 'CEST':
        cest_datetime = datetime.datetime.strptime("%s %s" % (fecha, hora), '%d/%m/%Y %H:%M')

        utc_datetime = cest_datetime - datetime.timedelta(hours=get_utc_offset())

    else:
        utc_datetime = datetime.datetime.strptime("%s %s" % (fecha, hora), '%d/%m/%Y %H:%M')

    now_timestamp = time.time()
    local = utc_datetime + (
            datetime.datetime.fromtimestamp(now_timestamp) - datetime.datetime.utcfromtimestamp(now_timestamp))

    return local


class Evento(object):
    def __new__(cls,** kwargs):
        try:
            datetime = date_to_local(kwargs['fecha'], kwargs['hora'], kwargs['formatTime'])
            instance =  object.__new__(cls)

            # __init__
            instance.datetime = datetime
            instance.fecha = datetime.date().strftime("%d-%m-%Y")
            instance.hora = datetime.time().strftime("%H:%M")
            instance.sport = kwargs['sport'].strip()
            instance.competition = kwargs['competition'].strip()
            instance.title = kwargs['title'].strip()
            instance.channels = kwargs['channels']
            instance.idiomas = ", ".join({c.get('idioma') for c in kwargs['channels'] if c.get('idioma')})

            return instance

        except:

            return None


    def __str__(self):
        return str((self.fecha, self.hora, self.sport, self.competition, self.title, self.channels))


    def isFinished(self):
        if self.sport in dict_deportes:
            ahora = datetime.datetime.now()
            duracion = datetime.timedelta(minutes=dict_deportes[self.sport].get('max'))
            return ahora > self.datetime + duracion
        else:
            return False


    def get_label(self):
        deporte = dict_deportes.get(self.sport, {})
        competicion = deporte.get('competitions', {}).get(self.competition, {})
        competicion_label = competicion.get('label', self.competition.title())

        label = "[COLOR lime]%s[/COLOR] (%s) %s [%s]" \
                % (self.hora, competicion_label, self.title, self.idiomas)

        return label

    def get_icon(self):
        deporte = dict_deportes.get(self.sport, {})
        competicion = deporte.get('competitions', {}).get(self.competition, {})

        return competicion.get('icon', deporte.get('icon'))


def mainmenu(item):
    itemlist = list()

    itemlist.append(item.clone(
        label='Agenda Linkotes',
        channel='arenavision',
        action='main',
        icon=os.path.join(image_path, 'logo.png'),
        url='https://linkotes.com',
        plot='Basada en la web https://linkotes.com'
    ))


    itemlist.append(item.clone(
        label='Agenda Acestream Spanish',
        channel='arenavision',
        action='main',
        icon=os.path.join(image_path, 'acestream_spanish.png'),
        url='http://acestreampi.ddns.net',
        plot='Basada en el grupo de Telegram: https://t.me/acestream_spanish'
    ))

    itemlist.append(item.clone(
        label='Agenda en imagen de ArenaVision',
        channel='arenavision',
        action='show_guide_img',
        icon=os.path.join(image_path, 'arenavisionlogo1.png'),
        url='http://arenavision.us',
        isFolder=False,
        plot='Muestra una imagen de la Agenda oficial de Arenavision.\nUse la tecla ESC para salir.'
    ))

    itemlist.append(item.clone(
        label='Canales ArenaVision',
        channel='arenavision',
        action='list_all_channels',
        icon=os.path.join(image_path, 'arenavisionlogo1.png'),
        url='http://arenavision.us',
        plot='Canales oficiales de Arenavision. Puedes escoger diferentes dominios desde el menu de ajustes.'
    ))

    return itemlist


def read_guide(item):
    if 'linkotes' in item.url:
        return read_guide_linkotes('https://friendpaste.com/6wl4zDOlqmLJIEubSR2ylm')

    if 'acestreampi.ddns' in item.url:
        return read_guide_acestream_spanish('http://acestreampi.ddns.net')


def read_guide_linkotes(url):
    guide = []

    data = urllib2.urlopen(urllib2.Request(url, headers={'Accept': 'application/json'})).read()
    try:
        data = eval(load_json(data)['snippet'])

        for e in data.get('Agenda_linkotes'):
            canales = list()
            idiomas = e.get('idiomas')

            for i, canal in enumerate(e.get('canales',[])):
                canales.append({'num': canal, 'idioma': idiomas[i]})

            if canales:
                evento = Evento(fecha=e['fecha'].replace('\\',''), hora=e['hora'], formatTime='CEST', sport=e['deporte'],
                                competition=e['competicion'], title=e['titulo'], channels=canales)

                if evento and (not evento.isFinished() or not get_setting('arena_hide')):
                    guide.append(evento)
    except:
        pass

    return guide


def read_guide_acestream_spanish(url):
    guide = []

    data = urllib2.urlopen(urllib2.Request(url, headers=headers)).read()
    patron = "<b>Dia: </b>([^<]+)<br><b>Hora: </b>0([^<]+)<br><b>Tipo: </b>([^<]+)<br>" \
             "<b>Competición: </b>([^<]+)<br><b>Evento: </b>([^<]+)<br>(.*?)<br>"

    for fecha, hora, tipo, competicion, titulo, canales in re.findall(patron,data):
        channels =list()

        for num, idioma in re.findall('(\d+)-(\w{3})', canales):
            channels.append({'num': num, 'idioma': idioma})

        if channels:
            tipo = tipo.replace('F\xc3\x9aTBOL', 'SOCCER')
            evento = Evento(fecha=fecha, hora=hora.replace(' CEST',''), formatTime='CEST',
                            sport=tipo, competition=competicion,
                            title=titulo, channels=channels)

            if evento and (not evento.isFinished() or not get_setting('arena_hide')):
                guide.append(evento)

    return guide


def get_categorias(item, guide=None):
    itemlist = []

    if not guide:
        guide = read_guide(item)

    sports_in_guide = {evento.sport for evento in guide}
    competitions_in_guide = {evento.competition for evento in guide}

    for sp in sports_in_guide:
        if sp in dict_deportes:
            deporte = dict_deportes[sp]
            itemlist.append(item.clone(
                label='%s' % deporte.get('label', sp.capitalize()),
                action='get_agenda',
                icon=deporte.get('icon'),
                sport=sp
            ))

            for comp in competitions_in_guide:
                if comp in deporte.get('competitions', []):
                    competicion = deporte.get('competitions')[comp]
                    itemlist.append(item.clone(
                        label='    - %s' % competicion.get('label', comp.capitalize()),
                        action='get_agenda',
                        icon=competicion.get('icon', item.icon),
                        sport=sp,
                        competition=comp
                    ))

    if itemlist:
        itemlist.insert(0, item.clone(label='Ver todos los eventos', action='get_agenda'))
    else:
        itemlist = get_agenda(item,guide)

    return itemlist


def get_agenda(item, guide=None):
    itemlist = []

    if not guide:
        guide = read_guide(item)

    fechas = []
    competiciones = []
    for evento in guide:
        if item.sport and (item.sport != evento.sport or (item.competition and item.competition != evento.competition)):
            continue

        if evento.fecha not in fechas:
            fechas.append(evento.fecha)
            label = '%s' % evento.fecha
            icon = os.path.join(image_path, 'logo.png')
            if item.sport:
                deporte = dict_deportes[item.sport]
                label += '   %s' % deporte.get('label', item.sport.capitalize())
                icon = deporte.get('icon', item.icon)
                if item.competition:
                    competicion = deporte.get('competitions')[item.competition]
                    label += ' - %s' % competicion.get('label', item.competition.capitalize())
                    icon = competicion.get('icon', item.icon)

            itemlist.append(item.clone(
                label= '[B][COLOR gold]%s[/COLOR][/B]' % label,
                icon= icon,
                action= None
            ))




        icon_evento = evento.get_icon()
        label = "[COLOR lime]%s[/COLOR]" % evento.hora
        deporte = dict_deportes.get(evento.sport, {})
        deporte_label = deporte.get('label', evento.sport.capitalize())
        competicion = deporte.get('competitions', {}).get(evento.competition, {})
        competicion_label = competicion.get('label', evento.competition.title())
        if not item.competition:
            if not item.sport:
                label += ' (%s - %s)' % (deporte_label, competicion_label)
            else:
                label += ' (%s)' % competicion_label


        itemlist.append(item.clone(
            title=evento.title,
            label='%s %s [%s]' % (label, evento.title, evento.idiomas),
            icon=icon_evento if icon_evento else item.icon,
            action = 'list_channels',
            channels = evento.channels
        ))

    return itemlist


def download_arenavision():
    data = None
    url = get_setting('arena_url')

    response = urllib2.urlopen(urllib2.Request(url, headers=headers))

    respose_url = response.geturl()[:-1] if response.geturl().endswith('/') else response.geturl()
    if url != respose_url:
        url = respose_url
        set_setting('arena_url', url)

    url_guide = re.findall('<a href="([^"]+)">EVENTS GUIDE', response.read())
    if url_guide:
        data = urllib2.urlopen(urllib2.Request(url + url_guide[0], headers=headers)).read()

    if not data:
        xbmcgui.Dialog().ok('1x2',
                            'Ups!  Parece que la página %s no funciona.' % url,
                            'Intentelo cambiando el dominio dentro de Ajustes.')

    return data


def list_channels(item):
    itemlist = list()

    data = download_arenavision()
    url_canal = {'{:0>2}'.format(canal): url for url, canal in re.findall('<a href="([^"]+)">ArenaVision (\d+)</a>', data)}

    for c in item.channels:
        num = '{:0>2}'.format(c['num'])
        url = (get_setting('arena_url') + url_canal.get(num)) if url_canal.get(num) else None
        if url:
            itemlist.append(item.clone(
                label= 'Canal [COLOR red]%s[/COLOR] [COLOR lime][%s][/COLOR]' % (num, c['idioma']),
                action= 'play',
                url= url
            ))

    return play(itemlist[0]) if len(itemlist) == 1 else itemlist


def list_all_channels(item):
    itemlist = list()

    data = download_arenavision()
    url_canal = {'{:0>2}'.format(canal): url for url, canal in re.findall('<a href="([^"]+)">ArenaVision (\d+)</a>', data)}

    for n in range(1,49):
        n = '{:0>2}'.format(n)
        url = (get_setting('arena_url') + url_canal.get(n)) if url_canal.get(n) else None
        if url:
            itemlist.append(item.clone(
                label= 'Canal [COLOR red]%s[/COLOR]' % n,
                action= 'play',
                url= url))

    return itemlist


def play(item):
    ret = None
    data = urllib2.urlopen(urllib2.Request(item.url, headers=headers)).read()

    tipo_url = re.findall('(id:|url=)"([^"]+)',data)
    if tipo_url:
        if tipo_url[0][0] == 'id:':
            ret = 'plugin://program.plexus/?mode=1&url=acestream://%s&name=Arenavision %s' % (tipo_url[0][1], item.label)

        elif tipo_url[0][0] == 'url=':
            ret = tipo_url[0][1]

        logger(ret)
        return ret

    xbmcgui.Dialog().ok('1x2',
                        'Ups!  Parece que en estos momentos no hay nada que ver en este canal.',
                        'Intentelo mas tarde o pruebe en otro canal, por favor.')
    return None


def show_guide_img(item):
    def sub(url):
        data = urllib2.urlopen(urllib2.Request(url, headers=headers))

        import tempfile
        fd, path = tempfile.mkstemp(suffix='.png')

        try:
            with os.fdopen(fd, 'w') as tmp:
                tmp.write(data.read())
            logger(path)
            ImageShower().showImage(path)

        finally:
            os.remove(path)

    data = download_arenavision()
    url = re.findall('src="(/static/[^\.]+.png)"', data)

    if url:
        url = get_setting('arena_url') + url[0]
        if get_setting('arena_visor'):
            data = urllib2.urlopen(urllib2.Request(url, headers=headers))
            path = os.path.join(data_path, 'agenda_arenavision.png')
            try:
                with open(path, 'wb') as tmp:
                    tmp.write(data.read())
            except:
                pass
            else:
                xbmc.executebuiltin('ShowPicture("{0}")'.format(path))
                xbmcgui.Dialog().notification('1x2',
                                              'Zoom: Teclas +/- Mover: Cursores',
                                              time= 3000)
        else:
            import threading
            threading.Thread(name='sub', target=sub, args=(url,)).start()


def main(item):
    itemlist = list()

    if download_arenavision():
        guide = read_guide(item)

        if get_setting('get_categorias'):
            itemlist =  get_categorias(item, guide)
        else:
            itemlist = get_agenda(item, guide)

        if not itemlist:
            xbmcgui.Dialog().ok('1x2',
                                'Ups!  Parece que en estos momentos no hay eventos programados.',
                                'Intentelo mas tarde, por favor.')

    return itemlist


class ImageShower(xbmcgui.Window):
    def showImage(self, image):
        w = self.getWidth()
        h = self.getHeight() * 2 

        self.addControl(xbmcgui.ControlImage(0, 0, w, h, image, aspectRatio=0))
        self.doModal()


    def onAction(self, action):
        self.close()

    def onControl(self, event):
        self.close()