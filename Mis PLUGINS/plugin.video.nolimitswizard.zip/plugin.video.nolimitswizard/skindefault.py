##==============
## Skin Default
##==============
import xbmc,xbmcaddon,xbmcgui,os,time,sys

import skinSwitch

AddonID = 'plugin.video.nolimitswizard'
ADDON=xbmcaddon.Addon(id='plugin.video.nolimitswizard')
ADDONPATH = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID))
AddonTitle = "[COLOR aqua]No Limits Wizard[/COLOR]"
HOME =  xbmc.translatePath('special://home/')
KODIVERSION = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
dialog = xbmcgui.Dialog()    
PATH = "No Limits Wizard"
VERSION = "2.6"


def SetDefaultSkin():
	skin = xbmc.getSkinDir()
	skinswapped = 0

	##SWITCH SKIN IF THE CURRENT SKIN IS NOT DEFAULT SKIN
	if skin not in ['skin.confluence','skin.estuary']:
            choice = dialog.yesno(AddonTitle, '[COLOR white]You are not using the Default Skin.[/COLOR]','[COLOR lightskyblue][B]Click YES[/B][/COLOR] [COLOR white]to AutoSwitch to the Default Skin.[/COLOR] [COLOR red][B]DO NOT PRESS[/B][/COLOR] [COLOR yellow]ANY Buttons or MOVE the Mouse[/COLOR] [COLOR white]while this automatic process takes place.[/COLOR]', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
            if choice == 0:
                sys.exit(1)
            skin = 'skin.estuary' if KODIVERSION >= 17 else 'skin.confluence'
            skinSwitch.swapSkins(skin)
            skinswapped = 1
            time.sleep(1)

	##IF A SKIN SWAP HAS HAPPENED, CHECK IF OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT'S PRESENT
	if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin( "Action(Select)" )
	
	##IF THERE'S NO YES/NO DIALOG (SWITCH TO DEFAULT SKIN), THEN SLEEP UNTIL IT APPEARS
	if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		time.sleep(1)
	
	##WHILE YES/NO DIALOG IS PRESENT, AUTOSELECT SKIN CHANGE (PRESS LEFT AND THEN SELECT)
	if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
		xbmc.executebuiltin( "Action(Left)" )
		xbmc.executebuiltin( "Action(Select)" )
		time.sleep(1)

	skin = xbmc.getSkinDir()

	#CHECK IF THE SKIN IS NOT DEFAULT SKIN
	if skin not in ['skin.confluence','skin.estuary']:
            if skinswapped == 1:
		choice = dialog.yesno(AddonTitle,'[COLOR yellow][B]ERROR: AutoSwitch was not Successful[/B][/COLOR]','[COLOR lightskyblue]Click Yes to manually switch to the Default Skin now. You can Press NO and try the AutoSwitch again if you wish.[/COLOR]', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR lightskyblue]NO[/COLOR][/B]')
		if choice == 1:
                    xbmc.executebuiltin("ActivateWindow(appearancesettings)")
                    return
		else:
                    sys.exit(1)
