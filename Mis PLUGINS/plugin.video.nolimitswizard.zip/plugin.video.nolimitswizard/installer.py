##==============
## Installer
##===============
import xbmc,xbmcaddon,xbmcgui,os,time
import skindefault
import downloader
import extract
import common

AddonID = 'plugin.video.nolimitswizard'
ADDON=xbmcaddon.Addon(id='plugin.video.nolimitswizard')
HOME =  xbmc.translatePath('special://home/')   
PATH = "No Limits Wizard"
VERSION = "2.6"

##============
##   WIZARD
##============
def WIZARD(name,url,description):
    AddonTitle = "[COLOR aqua]No Limits Wizard[/COLOR]"
    KODIVERSION = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    dialog = xbmcgui.Dialog()
    if KODIVERSION < 16.0:
        dialog.ok("[COLOR=red][B]WARNING !!! [/COLOR][/B]", "Your device has an old Version of Kodi that should be upgraded.")
        return
    else:
        skindefault.SetDefaultSkin()
        dp = xbmcgui.DialogProgress()

        ##  Fresh Start
        dp.create(AddonTitle,"Restoring Kodi.",'In Progress.............','Please Wait')
        common.FRESHSTARTBUILD()
        time.sleep(2)

        ##  Download
        dp.create(AddonTitle,"Downloading the Latest Build... ",'','Please Wait')
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, name+'.zip')
        try:
            os.remove(lib)
        except:
            pass
        downloader.download(url, lib, dp)
        time.sleep(2)

        ##  Extract from Zip File
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        dp.update(0,"", "Extracting Files from Zip File...")
        extract.all(lib,addonfolder,dp)

        ##  Cleanup Kodi
        common.CLEANUP(url)
        time.sleep(2)

        ##  Force Quit Kodi
        common.TIMER(15,"[COLOR aqua][B]DOWNLOAD is Complete[/B][/COLOR]","Kodi will shutdown automatically in: ", "For Android/Amazon devices: [COLOR yellow][B]Remove the power cable[/B][/COLOR] from your device [COLOR red][B]AFTER[/B][/COLOR] the countdown.")
        common.killxbmc()
