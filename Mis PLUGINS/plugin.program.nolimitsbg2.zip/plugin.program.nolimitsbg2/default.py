###################################
#	NO LIMITS BACKGROUNDS
###################################
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
##import os.path
import shutil
import urllib2,urllib
import re
import uservar
import fnmatch
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta

moveitdir        = ""
ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
##ADDON            = wiz.addonId(ADDON_ID)
##VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDON            = xbmcaddon.Addon(ADDON_ID)
VERSION          = ADDON.getAddonInfo('version')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
SOURCES          = os.path.join(USERDATA,  'sources.xml')
FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
PROFILES         = os.path.join(USERDATA,  'profiles.xml')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
FANART           = os.path.join(PLUGIN,    'fanart.jpg')
ICON             = os.path.join(PLUGIN,    'icon.png')
ART              = os.path.join(PLUGIN,    'resources', 'art')
WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
SKIN             = xbmc.getSkinDir()
##BUILDNAME        = wiz.getS('buildname')
##DEFAULTSKIN      = wiz.getS('defaultskin')
##DEFAULTNAME      = wiz.getS('defaultskinname')
##DEFAULTIGNORE    = wiz.getS('defaultskinignore')
##BUILDVERSION     = wiz.getS('buildversion')
##BUILDTHEME       = wiz.getS('buildtheme')
##BUILDLATEST      = wiz.getS('latestversion')
##SHOW15           = wiz.getS('show15')
##SHOW16           = wiz.getS('show16')
##AUTOCLEANUP      = wiz.getS('autoclean')
##AUTOCACHE        = wiz.getS('clearcache')
##AUTOPACKAGES     = wiz.getS('clearpackages')
##SEPERATE         = wiz.getS('seperate')
##NOTIFY           = wiz.getS('notify')
##NOTEID           = wiz.getS('noteid')
##NOTEDISMISS      = wiz.getS('notedismiss')
##TRAKTSAVE        = wiz.getS('traktlastsave')
##REALSAVE         = wiz.getS('debridlastsave')
##LOGINSAVE        = wiz.getS('loginlastsave')
##KEEPFAVS         = wiz.getS('keepfavourites')
##KEEPSOURCES      = wiz.getS('keepsources')
##KEEPPROFILES     = wiz.getS('keepprofiles')
##KEEPADVANCED     = wiz.getS('keepadvanced')
##KEEPTRAKT        = wiz.getS('keeptrakt')
##KEEPREAL         = wiz.getS('keepdebrid')
##KEEPLOGIN        = wiz.getS('keeplogin')
##LOGINSAVE        = wiz.getS('loginlastsave')
##DEVELOPER        = wiz.getS('developer')
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
MCNAME           = "Kodi"
EXCLUDES         = uservar.EXCLUDES
BUILDFILE        = uservar.BUILDFILE
COMMFILE	 = uservar.COMMFILE
SKINFILE	 = uservar.SKINFILE
APKFILE          = uservar.APKFILE
##WORKINGURL       = wiz.workingURL(BUILDFILE)
##APKWORKINGURL    = wiz.workingURL(APKFILE)
##UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
##NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
NOTIFICATION     = uservar.NOTIFICATION
ENABLE           = uservar.ENABLE
HEADERMESSAGE    = uservar.HEADERMESSAGE
AUTOUPDATE       = uservar.AUTOUPDATE
WIZARDFILE       = uservar.WIZARDFILE
HIDECONTACT      = uservar.HIDECONTACT
CONTACT          = uservar.CONTACT
HIDESPACERS      = uservar.HIDESPACERS
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
THEME4           = uservar.THEME4
THEME5           = uservar.THEME5
THEME6           = uservar.THEME6
THEME7           = uservar.THEME7
ICONMAINT        = uservar.ICONMAINT if not uservar.ICONMAINT == 'http://' else ICON
ICONSC1          = uservar.ICONSC1 if not uservar.ICONSC1 == 'http://' else ICON
ICONSC2          = uservar.ICONSC2 if not uservar.ICONSC2 == 'http://' else ICON
ICONSC3          = uservar.ICONSC3 if not uservar.ICONSC3 == 'http://' else ICON
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON
ICONAPK          = uservar.ICONAPK if not uservar.ICONAPK == 'http://' else ICON
ICONCONTACT      = uservar.ICONCONTACT if not uservar.ICONCONTACT == 'http://' else ICON
ICONSAVE         = uservar.ICONSAVE if not uservar.ICONSAVE == 'http://' else ICON
ICONREAL         = uservar.ICONREAL if not uservar.ICONREAL == 'http://' else ICON
ICONLOGIN        = uservar.ICONLOGIN if not uservar.ICONLOGIN == 'http://' else ICON
ICONTRAKT        = uservar.ICONTRAKT if not uservar.ICONTRAKT == 'http://' else ICON
ICONSETTINGS     = uservar.ICONSETTINGS if not uservar.ICONSETTINGS == 'http://' else ICON
##LOGFILES         = wiz.LOGFILES
##TRAKTID          = traktit.TRAKTID
##DEBRIDID         = debridit.DEBRIDID
##LOGINID          = loginit.LOGINID
##INTRO 	 = xbmc.translatePath(os.path.join('special://home/addons/plugin.program.nolimitstools/intro.mp4'))  
##YTDATA	 = xbmc.translatePath('special://userdata/addon_data/plugin.video.youtube/')
THDATA	 	 = xbmc.translatePath('special://userdata/Thumbnails/')

   

###########################
###### Menu Items   #######
###########################
#addDir (display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)
#addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None)

def index():
	on = '[COLOR green]ON[/COLOR]'; off = '[COLOR red]OFF[/COLOR]'
        addFile('[COLOR aqua][B][Backgrounds Menu][/B][/COLOR]', '', themeit=THEME3)
	addFile('Clear All Background Images'    ,'clearbackgrounds', icon=ICONSETTINGS, themeit=THEME1)
	addFile('Change to Blue Ice Backgrounds' ,'backgrounds2', icon=ICONSETTINGS, themeit=THEME1)
	##addFile('Change to Original Backgrounds' ,'backgrounds1', icon=ICONSETTINGS, themeit=THEME1)
	setView('files', 'MAIN')

###########################
## Clear Background Images
###########################

def clearbackgrounds():
    ## Leaves empty Directories
    ADDONTITLE = "[COLOR aqua]No Limits[/COLOR] [COLOR white]Backgrounds[/COLOR]"
    dialog = xbmcgui.Dialog()
    if DIALOG.yesno(ADDONTITLE, "Would You Like To Clear The Backgrounds Folder?", "Restart Required!", nolabel='No, Abort',yeslabel='Yes, Remove'):
        clearbackgroundssubroutine()
        dialog.ok(ADDONTITLE, "All Background Images were Removed", "")

def clearbackgroundssubroutine():        
    dialog = xbmcgui.Dialog()
    backgrounds_path = xbmc.translatePath(os.path.join('special://home/media/backgrounds', ''))
    try:    
        for root, dirs, files in os.walk(backgrounds_path):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                    ##for d in dirs:
                    ##shutil.rmtree(os.path.join(root, d))
    except: pass

def clearbackgroundsOLDNoDirs():
    ## Erases Both Files and Directories
    BACKGROUNDPATH = xbmc.translatePath('special://home/media/backgrounds/')
    if DIALOG.yesno(ADDONTITLE, "Would You Like To Clear The Backgrounds Folder?", "Restart Required!", nolabel='No, Abort',yeslabel='Yes, Remove'):
        shutil.rmtree(BACKGROUNDPATH)
        killxbmc()
    else: log('Clear Backgrounds Aborted')


#############################
## Use Original Backgrounds 1
#############################
def usebackgrounds1():
    back=None

                    
#############################
## Use Blue Ice Backgrounds 2
#############################
def usebackgrounds2():
    ADDONTITLE = "[COLOR aqua]No Limits[/COLOR] [COLOR white]Backgrounds[/COLOR]"
    dialog = xbmcgui.Dialog()
    if DIALOG.yesno(ADDONTITLE, "Would You Like To Use The Blue Ice Backgrounds?", "", nolabel='No, Abort',yeslabel='Yes, Use'): 
        clearbackgroundssubroutine()

        moveitdir = "bennu/"
        moveitfiles(moveitdir)
        moveitdir = "bob/"
        moveitfiles(moveitdir)
        moveitdir = "herplace/"
        moveitfiles(moveitdir)
        moveitdir = "kids/"
        moveitfiles(moveitdir)
        moveitdir = "livetv/"
        moveitfiles(moveitdir)
        moveitdir = "movies/"
        moveitfiles(moveitdir)
        moveitdir = "music/"
        moveitfiles(moveitdir)
        moveitdir = "networks/"
        moveitfiles(moveitdir)
        moveitdir = "power/"
        moveitfiles(moveitdir)
        moveitdir = "quantum/"
        moveitfiles(moveitdir)
        moveitdir = "sports/"
        moveitfiles(moveitdir)
        moveitdir = "system/"
        moveitfiles(moveitdir)
        moveitdir = "tools/"
        moveitfiles(moveitdir)
        moveitdir = "tvshows/"
        moveitfiles(moveitdir)
        moveitdir = "ukturks/"
        moveitfiles(moveitdir)
        moveitdir = "xxx/"
        moveitfiles(moveitdir)
        ##moveitdir = ""
        ##moveitfiles(moveitdir)
        ##dialog.ok(ADDONTITLE, "Blue Ice Background Images are Ready", "")
    else: log('Use Blue Ice Backgrounds Aborted')
       
        
def moveitfiles(moveitdir):
    ### import os, shutil
    path = xbmc.translatePath(os.path.join('special://home/addons//plugin.program.nolimitsbg2/backgrounds/' + moveitdir, ''))
    moveto = xbmc.translatePath(os.path.join('special://home/media/backgrounds/' + moveitdir, ''))
    for root, dirs, files in os.walk(path):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            for f in files:
                src = path+f
                ##dialog.ok(ADDONTITLE, src, "")
                dst = moveto+f
                ##dialog.ok(ADDONTITLE, dst, "")
                shutil.move(src,dst)

def usebackgrounds2x():
        src = "special://home/addons/plugin.program.nolimitsbg2/backgrounds/*.*"
        dst = "special://home/media/backgrounds/"
        ADDONTITLE = "[COLOR aqua]No Limits[/COLOR] [COLOR white]Backgrounds[/COLOR]"
        shutil.move(src,dst)
        dialog.ok(ADDONTITLE, dst, " Finished")
    
def usebackgrounds2y():
    ### import os, shutil
    path = xbmc.translatePath(os.path.join('special://home/addons//plugin.program.nolimitsbg2/backgrounds/livetv/', ''))
    moveto = xbmc.translatePath(os.path.join('special://home/media/backgrounds/', ''))
    ADDONTITLE = "[COLOR aqua]No Limits[/COLOR] [COLOR white]Backgrounds[/COLOR]"
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(path):
        file_count = 0
        file_count += len(files)
        if file_count > 0:
            ##for d in dirs:
                for f in files:
                    src = path+f
                    ##dialog.ok(ADDONTITLE, src, "")
                    dst = moveto+f
                    ##dialog.ok(ADDONTITLE, dst, "")
                    shutil.move(src,dst)

    
def usebackgrounds2z():
    if DIALOG.yesno(ADDONTITLE, "Would You Like To Use The Blue Ice Backgrounds?", "Restart Required!", nolabel='No, Abort',yeslabel='Yes, Use'):
        ### import os, shutil, os.path
        path = "special://home/addons/plugin.program.nolimitsbg2/backgrounds/livetv/"
        moveto = "special://home/media/backgrounds/livetv/"
        files = os.listdir(path)
        files.sort()
        for f in files:
            src = path+f
            dst = moveto+f
            shutil.move(src,dst)
        ##killxbmc()
    else: log('Use Blue Ice Backgrounds Aborted')

##########################
###DETERMINE PLATFORM#####
##########################

def platform():
	if xbmc.getCondVisibility('system.platform.android'):   return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):   return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):	return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):    return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):	return 'ios'

#############################
####KILL XBMC ###############
#####THANKS GUYS @ TI########

def killxbmc():
	choice = DIALOG.yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
	if choice == 0: return
	elif choice == 1: pass
	myplatform = platform()
	log("Platform: " + str(myplatform))
	os._exit(1)
	log("Force close failed!  Trying alternate methods.")
	if myplatform == 'osx': # OSX
		log("############ try osx force close #################")
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'linux': #Linux
		log("############ try linux force close #################")
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'android': # Android 
		log("############ try android force close #################")
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass		
		try: os.system('adb shell kill org.xbmc.kodi')
		except: pass
		try: os.system('adb shell kill org.kodi')
		except: pass
		try: os.system('adb shell kill org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell kill org.xbmc')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
		except: pass
		DIALOG.ok(ADDONTITLE, "Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows': # Windows
		log("############ try windows force close #################")
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
	else: #ATV
		log("############ try atv force close #################")
		try: os.system('killall AppleTV')
		except: pass
		log("############ try raspbmc force close #################") #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected. Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")


def log(log):
	xbmc.log("[%s]: %s" % (ADDONTITLE, log))
	if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
	if not os.path.exists(WIZLOG): f = open(WIZLOG, 'w'); f.close()
	with open(WIZLOG, 'a') as f:
		line = "[%s %s] %s" % (datetime.now().date(), str(datetime.now().time())[:8], log)
		f.write(line.rstrip('\r\n')+'\n')

###########################
###### Settings Items #####
###########################

def getS(name):
	try: return ADDON.getSetting(name)
	except: return False

def setS(name, value):
	try: ADDON.setSetting(name, value)
	except: return False

def openS():
	ADDON.openSettings()

###########################
## Making the Directory####
###########################

def addDir(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None):
	u='%s?mode=%s' % (sys.argv[0], urllib.quote_plus(mode))
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": ADDONTITLE} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addFile(display,mode,name=None,url=None,menu=None,overwrite=True,fanart=FANART,icon=ICON, themeit=None):
	u='%s?mode=%s' % (sys.argv[0], urllib.quote_plus(mode))
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": ADDONTITLE} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

		return param

params=get_params()
url=None
name=None
mode=None

try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass

log('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]' % (VERSION, mode if not mode == '' else None, name, url))

def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if getS('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % getS(viewType) )


if   mode==None             : index()

elif mode=='clearbackgrounds'    : clearbackgrounds()
elif mode=='backgrounds1'        : usebackgrounds1()
elif mode=='backgrounds2'        : usebackgrounds2()

xbmcplugin.endOfDirectory(int(sys.argv[1]))