# repo.twilight0.libs
Repository for library addons

Contains streamlink, tulip & some other dependencies

You can get them by adding these to your repository addon.xml

    <dir>
        <info compressed="false">https://raw.githubusercontent.com/Twilight0/repo.twilight0.libs/master/_zips/addons.xml</info>
        <checksum>https://raw.githubusercontent.com/Twilight0/repo.twilight0.libs/master/_zips/addons.xml.md5</checksum>
        <datadir zip="true">https://raw.githubusercontent.com/Twilight0/repo.twilight0.libs/master/_zips/</datadir>
    </dir>
