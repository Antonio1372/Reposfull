# -*- coding: utf-8 -*-

import xbmcgui
from resources.lib.modules.colors import GetColorHex
from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class Home_Service(xbmcgui.WindowXML):

	MYACCOUNT     = 1001
	SETTING       = 1002
	CLOSE         = 1005
	QUICKLINKS    = 1006

	ACTION_MOUSE_LEFT_CLICK = 100
	ACTION_PREVIOUS_MENU    = 10
	ACTION_SELECT_ITEM      = 7
	ACTION_BACK             = 92
	ACTION_NAV_BACK         = 92

	def __new__(cls):
		return super(Home_Service, cls).__new__(cls, 'Service_Home.xml', addon_path)

	def __init__(self,):
		super(Home_Service,self).__init__()
		self.LISTITEM = [('EPG',9,'epg'),
						('Live TV',1,'live'),
						('On Demand',6,'vod'),
						('QuickLinks',100,'quicklinks'),
						('Account Info',100,'accountinfo'),
						('Settings',100,'settings'),
						('Tools',100,'tool'),
						('Close',100,'close')]

	def onInit(self):
		self.setProperty('COLOR',GetColorHex('purple'))
		self.control_list = self.getControl(2000)
		if self.control_list.size() > 0:
			self.Reset(2000)
		for item in self.LISTITEM:
			label  = item[0]
			mode   = item[1]
			cat    = item[2]
			ItemList = xbmcgui.ListItem(label)
			ItemList.setProperty('mode',str(mode))
			ItemList.setProperty('cat',cat)
			self.control_list.addItem(ItemList)
		self.setFocusId(2000)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))

	def onClick(self, control):
		Log('onClick: {}'.format(control))
			
	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			Log('Action Focus {} Pos {}'.format(ActionID,self.control_list.getSelectedPosition()))
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				label = self.control_list.getListItem(int(gsp)).getLabel()
				mode = int(self.control_list.getListItem(int(gsp)).getProperty('mode'))
				cat = self.control_list.getListItem(int(gsp)).getProperty('cat')
				if mode < 100:
					RunModule(url=cat,mode=mode,name='purple')
				else:
					if cat == 'quicklinks':
						import quicklinks
						d=quicklinks.QuickLinks()
						d.doModal()
						del d
					elif cat == 'accountinfo':
						import dialog_text
						d=dialog_text.Account_Info()
						d.doModal()
						del d
					elif cat == 'settings':
						OpenSettings()
					elif cat == 'tool':
						import dir_tools
						d=dir_tools.MainMenu(directstart=False)
						d.doModal()
						del d 
					elif cat == 'close':
						self.Close(msg='Closing via close list item')
					else:
						self.Close(msg='{} cat mode not valid entry'.format(cat))
		elif action == self.ACTION_NAV_BACK:
			self.Close('Closing via action nav back')
					
	def onFocus(self,control):
		Log('onFocus: {}'.format(control))
		pass


	def setControlVisible(self, controlId, visible):
		if not controlId:
			return
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()	

	def Close(self,msg='Home_Service closing'):
		Log(msg)
		xbmc.executebuiltin('XBMC.ActivateWindow(Home)')

