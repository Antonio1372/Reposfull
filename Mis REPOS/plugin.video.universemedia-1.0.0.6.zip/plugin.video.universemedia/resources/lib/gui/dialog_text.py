# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules import panelcalls

class Text_Viewer(xbmcgui.WindowXMLDialog):

	BUTTON_CLOSE = 100
	HEADING_CTRL = 200
	TEXT_CTRL    = 201

	def __new__(cls,header,text,color):
		return super(Text_Viewer, cls).__new__(cls, 'Text_Box.xml', addon_path)

	def __init__(self,header,text,color):
		super(Text_Viewer,self).__init__()
		self.HEADER = header
		self.TEXT   = text
		self.COLOR  = color

	def onInit(self):
		self.setProperty('COLOR',self.COLOR)
		self.setFocusId(self.BUTTON_CLOSE)
		self.setControlLabel(self.HEADING_CTRL,self.HEADER)
		self.setControlText(self.TEXT_CTRL,self.TEXT)

	def onClick(self, controlId):
		Log('onClick: {}'.format(controlId))
		if controlId == self.BUTTON_CLOSE:
			self.Close('Closing text box via close button')

	def setVisableId(self,controlId,visible):
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def setFocusId(self, controlId):
		control = self.getControl(controlId)
		if control:
			self.setFocus(control)

	def setControlText(self, controlId, text):
		control = self.getControl(controlId)
		if control:
			control.setText(text)

	def setControlLabel(self,controlId,label):
		control = self.getControl(controlId)
		if control:
			control.setLabel(label)

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()

	def Close(self,msg='Closing text box'):
		Log(msg)
		self.close()


class Account_Info(xbmcgui.WindowXMLDialog):

	HEADING_CTRL = 200
	TEXT_CTRL   = 201

	def __new__(cls):
		return super(Account_Info, cls).__new__(cls, 'Text_Box.xml', addon_path)

	def __init__(self):
		super(Account_Info,self).__init__()
		self.AccountInfo()
		self.setColor('purple')
		self.setHeading(self.header)
		self.setText(self.text)

	def AccountInfo(self):
		epg_data = panelcalls.GetEpg()
		userinfo = epg_data.get('user_info')
		self.username = userinfo.get('username')
		self.maxcon   = userinfo.get('max_connections')
		self.status   = userinfo.get('status')
		expdate  = userinfo.get('exp_date')
		if expdate:
			self.expdate = FromTimeStamp(float(expdate),fmt='%H:%M %d.%m.%Y') 
		else:
			self.expdate = 'Never'
		self.trial    = 'No' if userinfo.get('is_trial') == '0' else 'Yes'
		self.text = 'Username: {}\n\nStatus: {}\n\nExpiry  Date: {}\n\nMax Connections: {}\n\nTrial: {}'.format(self.username,self.status,self.expdate,self.maxcon,self.trial)
		self.header ='Universe Media user account details'.title()



	def setColor(self,color):
		self.setProperty('COLOR',color)

	def setHeading(self, header):
		self.setProperty('HEADER',self.header)

	def setText(self,text):
		self.setProperty('TEXT',self.text)