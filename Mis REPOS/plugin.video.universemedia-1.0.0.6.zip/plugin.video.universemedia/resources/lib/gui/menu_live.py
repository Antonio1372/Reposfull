# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules.colors import GetColorHex
from resources.lib.modules import panelcalls



class Menu_Live(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM       = 7
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100
	ACTION_MOUSE_RIGHT_CLICK = 101
	ACTION_MOUSE_LONG_CLICK  = 108
	ACTION_CONTEXT_MENU      = 117

	BUTTON_BACK = 1000

	LISTITEMS = 2000

	FADE_BOTTOM = 3003
	FADE_LEFT   = 3000
	FADE_RIGHT  = 3001 
	FADE_TOP    = 3002

	BUTTON_STOP = 4001 
	TEXTBOXL    = 4003
	TEXTBOXS    = 4004



	def __new__(cls,item_list,color,fade=[]):
		return super(Menu_Live, cls).__new__(cls, 'Live_Menu.xml', addon_path)

	def __init__(self,item_list,color,fade=[]):
		super(Menu_Live,self).__init__()
		self.LISTITEM = item_list
		self.COLOR = color
		self.FADE_LIST = fade

	def onInit(self):
		if xbmc.getCondVisibility('Player.HasMedia'):
			self.setControlVisible(self.TEXTBOXL, False)
			self.setControlVisible(self.TEXTBOXS, True)
		else:
			self.setControlVisible(self.TEXTBOXS, False)
			self.setControlVisible(self.TEXTBOXL, True)
		self.setProperty('COLOR',self.COLOR)
		self.setFadeVisable()
		self.control_list = self.getControl(self.LISTITEMS)
		if self.control_list.size() > 0:
			self.Reset(self.LISTITEMS)
		for item in self.LISTITEM:
			ItemList = xbmcgui.ListItem(item[0])
			ItemList.setPath(item[1])
			ItemList.setInfo('video',{ 'plot':item[2]})
			ItemList.setProperty('IsPlayable','true')
			ItemList.setProperty('IsFolder','false')
			self.control_list.addItem(ItemList)
		self.setFocusId(self.LISTITEMS)

	def onFocus(self, control):
		Log('onFocus: {}'.format(control))
		pass

	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				label = self.control_list.getListItem(int(gsp)).getLabel()
				url = self.control_list.getListItem(int(gsp)).getPath()
				RunModule(url=url,mode=3,name=label)
		elif action == self.ACTION_NAV_BACK:
			self.close()
		elif action in [self.ACTION_MOUSE_RIGHT_CLICK,self.ACTION_MOUSE_LONG_CLICK,self.ACTION_CONTEXT_MENU]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				label = self.control_list.getListItem(int(gsp)).getLabel()
				url = self.control_list.getListItem(int(gsp)).getPath()
				mode = 13
				u=CreateModule(url=url,mode=mode,name=label)
				item_list = [('[I]Add to Favourites[/I]',u,0),('[I]Add to QuickLink[/I]',u,1)]
				if HasAddon('plugin.program.super.favourites'):
					item_list.append(('[I]Add to Super Favourites[/I]',u,3))
				if mode==13:
					item_list.append(('[I]Play[/I]',u,2))
				from resources.lib.gui import context_menu
				d=context_menu.ContextMenu(item_list=item_list)
				d.doModal()
				del d 

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.BUTTON_BACK:
			self.Close()
		elif control == self.BUTTON_STOP:
			xbmc.executebuiltin('PlayerControl(Stop)')
			self.setControlVisible(self.TEXTBOXS, False)
			self.setControlVisible(self.TEXTBOXL, True)


	def setControlVisible(self, controlId, visible):
		Log(controlId)
		if not controlId:
			return
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()	

	def Close(self,msg='Live_Menu closing'):
		Log(msg)
		self.close()
		
	def setFadeVisable(self):
		#used to darken the screen on a side 
		FADES = [self.FADE_BOTTOM,self.FADE_LEFT,self.FADE_RIGHT,self.FADE_TOP]
		SHOW = []
		for f in self.FADE_LIST:
			SHOW.append(eval('self.FADE_{}'.format(f.upper())))
		HIDE = list(set(FADES)-set(SHOW))
		for s in SHOW:
			self.setControlVisible(s,True)
		for h in HIDE:
			self.setControlVisible(h,False)	

def MenuLive(title,url):
	livelist = panelcalls.GetLiveList(title,url)
	d=Menu_Live(livelist,GetColorHex('purple'),fade=['left','right'])
	d.doModal()
	del d