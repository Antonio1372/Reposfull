# -*- coding: utf-8 -*-
import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *


ACTION_SELECT_ITEM       = 7
ACTION_PREVIOUS_MENU     = 10
ACTION_NAV_BACK          = 92
ACTION_MOUSE_LEFT_CLICK  = 100



KEY_ESC      = 61467
KEY_NAV_BACK = 92


class Dialog_List(xbmcgui.WindowXMLDialog):

	OK_BUTTON     = 1002
	YES_BUTTON    = 1003
	NO_BUTTON     = 1004
	REMIND_BUTTON = 1005
	CLOSE_BUTTON  = 1006

	HEADER = 2000

	ITEM_LIST = 3000



	def __new__(cls,buttons,label,itemlist,color):
		return super(Dialog_List, cls).__new__(cls, 'List_Dialog.xml', addon_path)

	def __init__(self,buttons,label,itemlist,color):
		super(Dialog_List,self).__init__()
		self.buttons       = buttons
		self.label         = label
		self.color         = color
		self.itemlist      = itemlist
		self.SELPOS        = None

	def onAction(self,action):
		Log('onAction {}'.format(action.getId()))
		focus = self.getFocusId()
		if action in [ACTION_SELECT_ITEM,ACTION_MOUSE_LEFT_CLICK]:
			if focus == self.ITEM_LIST:
				self.SELPOS = self.getControl(self.ITEM_LIST).getSelectedPosition()
				self.Close('list item selected')


	def onInit(self):
		self.setButtons()
		self.setProperty('COLOR',self.color)
		self.setControlLabel(2000,self.label)
		self.setListitems(self.ITEM_LIST,self.itemlist)

	def onClick(self, controlId):
		Log('onClick: {}'.format(controlId))
		if controlId == self.CLOSE_BUTTON:
			self.Close('Closed via close button({})'.format(controlId))

	def setListitems(self,controlId,listitems):
		control = self.getControl(self.ITEM_LIST)
		if control:
			control.addItems(listitems)

	def setVisableId(self,controlId,visible):
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def setFocusId(self, controlId):
		control = self.getControl(controlId)
		if control:
			self.setFocus(control)

	def setControlText(self, controlId, text):
		control = self.getControl(controlId)
		if control:
			control.setText(text)

	def setControlLabel(self,controlId,label):
		control = self.getControl(controlId)
		if control:
			control.setLabel(label)

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()

	def Close(self,msg='closing Dialog_List'):
		Log(msg)
		super(Dialog_List,self).close()

	def setButtons(self):
		BUTTONS = [self.OK_BUTTON,self.YES_BUTTON,self.NO_BUTTON,self.REMIND_BUTTON,self.CLOSE_BUTTON]
		ENABLE = list()
		for button in self.buttons:
			b = eval('self.{}_BUTTON'.format(button.upper()))
			ENABLE.append(b)
		a = set(BUTTONS)
		b = set(ENABLE)
		DISABLE = list(a-b)
		Log(DISABLE)
		for c in DISABLE:
			self.setVisableId(controlId=c,visible=False)