

from resources.lib.modules._addon import *
from resources.lib.modules._common import *






class Dialog_Action(xbmcgui.WindowXMLDialog):

	OK_BUTTON  = 1002
	YES_BUTTON = 1003
	NO_BUTTON  = 1004
	REMIND_BUTTON = 1005

	HEADER = 2000
	TEXT   = 2001


	def __new__(cls,buttons,label,msg,color):
		return super(Dialog_Action, cls).__new__(cls, 'Action_Dialog.xml', addon_path)

	def __init__(self,buttons,label,msg,color):
		super(Dialog_Action,self).__init__()
		self.buttons       = buttons
		self.label         = label
		self.msg           = msg
		self.color         = color
		self.button_ok     = False
		self.button_yes    = False
		self.button_no     = False
		self.button_remind = False

	def onInit(self):
		self.setProperty('COLOR',self.color)
		labelcontrol = self.getControl(self.HEADER)
		labelcontrol.setLabel(self.label)
		textcontrol = self.getControl(self.TEXT)
		textcontrol.setText(self.msg)
		self.setButtons()

	def onClick(self, controlId):
		Log('Dialog_Action onClick {}'.format(controlId))
		if controlId   == self.OK_BUTTON:
			self.button_ok = True
			self.Close()
		elif controlId == self.YES_BUTTON:
			self.button_yes = True
			self.Close()
		elif controlId == self.NO_BUTTON:
			self.button_no = True
			self.Close()	
		elif controlId == self.REMIND_BUTTON:
			self.button_remind = True
			self.Close()
		else:
			Log('controlId Does not match a button')	


	def setButtons(self):
		BUTTONS = [self.OK_BUTTON,self.YES_BUTTON,self.NO_BUTTON,self.REMIND_BUTTON]
		ENABLE = list()
		for button in self.buttons:
			b = eval('self.{}_BUTTON'.format(button.upper()))
			ENABLE.append(b)
		a = set(BUTTONS)
		b = set(ENABLE)
		DISABLE = list(a-b)
		Log(DISABLE)
		for c in DISABLE:
			self.setControlVisible(controlId=c,visible=False)


	def setControlVisible(self, controlId, visible):
		if not controlId:
			return
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def Close(self,msg='Closing Dialog_Action'):
		Log(msg)
		super(Dialog_Action,self).close()
