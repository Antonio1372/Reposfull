import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET

from resources.lib.modules._addon import *
from resources.lib.modules._common import *


ACTION_SELECT_ITEM       = 7
ACTION_PREVIOUS_MENU     = 10
ACTION_NAV_BACK          = 92
ACTION_MOUSE_LEFT_CLICK  = 100

CLOSE_BUTTON = 4000

KEY_ESC      = 61467
KEY_NAV_BACK = 92


class MainMenu(xbmcgui.WindowXML):

	BUTTON_EXT_INFO_SCRIPT = 1001
	BUTTON_EPG             = 1002
	BUTTON_MAINTENANCE     = 1003
	BUTTON_TOOL            = 1004
	BUTTON_CLOSE           = 6000

	def __new__(cls,directstart):
		return super(MainMenu, cls).__new__(cls, 'Tool_Dir.xml', addon_path)

	def __init__(self,directstart):
		super(MainMenu,self).__init__()
		self.COLOR      = 'purple'
		self.Epgs       = ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']
		self.MyEpgList  = self.MyEpgList()
		self.dialog     = xbmcgui.Dialog()
		self.DIRECTSTART = directstart
		if HasAddon('script.extendedinfo'):
			self.addon_ext         = xbmcaddon.Addon('script.extendedinfo')
			self.addon_ext_info    = self.addon_ext.getAddonInfo
			self.setting_ext       = self.addon_ext.getSetting
			self.setting_true_ext  = lambda x: bool(True if setting_ext(str(x)) == "true" else False)
			self.setting_set_ext   = self.addon_ext.setSetting
			self.addon_ext_path    = TranslatePath('script.extendedinfo','path')
			self.addon_ext_profile = TranslatePath('script.extendedinfo','profile')


	def onInit(self):
		self.setProperty('COLOR',self.COLOR)
		self.setFocusId(self.BUTTON_EXT_INFO_SCRIPT)


	def onFocus(self,controlId):
		Log('onFocus {}'.format(controlId))
		if controlId == self.BUTTON_EXT_INFO_SCRIPT:
			self.Extinfo_Menu()
		elif controlId == self.BUTTON_EPG:
			self.Epg_Menu()
		elif controlId == self.BUTTON_MAINTENANCE:
			self.Maintenance_Menu()
		elif controlId == self.BUTTON_TOOL:
			self.Tool_Menu()


			

	def onClick(self, controlId):
		Log('onClick: {}'.format(controlId))
		if controlId == self.BUTTON_CLOSE:
			if self.DIRECTSTART:
				xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
			else:
				self.Close()


	def onAction(self,action):
		Log('Action: {}'.format(action.getId()))
		if action.getId() in [ACTION_NAV_BACK,ACTION_PREVIOUS_MENU]:
			self.Close('Tools Menu closed via action {}'.format(action.getId()))
		elif action.getId() == ACTION_PREVIOUS_MENU and action.getButtonCode() == KEY_ESC:
			self.Close('Tool Menu closed via escape')
		elif action.getId() in [ACTION_SELECT_ITEM,ACTION_MOUSE_LEFT_CLICK]:
			ActionID = self.getFocusId()
			if ActionID == 2000:
				gsp = self.control_list.getSelectedPosition()
				listitems = self.control_list.getListItem(int(gsp))
				mode = self.control_list.getListItem(int(gsp)).getProperty('mode')
				submode = int(self.control_list.getListItem(int(gsp)).getProperty('submode'))
				if mode == 'extendedinfo':
					self.Extinfo_Action(submode)
				elif mode =='epg':
					self.Epg_Action(submode,listitems)
				elif mode == 'maintenance':
					self.Maintenance_Action(submode)
				elif mode == 'tools':
					self.Tool_Action(submode)


	def setVisableId(self,controlId,visible):
		control = self.getControl(controlId)
		if control:
			control.setVisible(visible)

	def setFocusId(self, controlId):
		control = self.getControl(controlId)
		if control:
			self.setFocus(control)

	def setControlText(self, controlId, text):
		control = self.getControl(controlId)
		if control:
			control.setText(text)

	def setControlLabel(self,controlId,label):
		control = self.getControl(controlId)
		if control:
			control.setLabel(label)

	def Reset(self,controlId):
		control = self.getControl(controlId)
		if control:
			control.reset()

	def Close(self,msg='Closing Tools Menu'):
		Log(msg)
		self.close()

	def Tool_Menu(self):
		self.Reset(4003)
		self.setControlText(4003,'')
		#items title,icon,info,action,additional info 
		items = [('View Log',addon_icon,'View kodi log file,for information about this addon enable debug in settings',0),
				 ('Settings Backup',addon_icon,'Back user settings',1),
				 ('Settings Restore',addon_icon,'Restore user settings',2),
				 ('Host/Port Restore',addon_icon,'Restore Host and Port to default',3),
				 ('Save Log File',addon_icon,'Save kodi log file to removable device, device must be added as a source to do this',4),
				 ('Edit Favourites',addon_icon,'Edit Addon favourites that have been created via addon',5),
				 ('Settings.xml',addon_icon,'Removes settings.xml file',6)]
		self.control_list = self.getControl(2000)
		self.control_list.reset()
		for item in items:
			ItemList = xbmcgui.ListItem(item[0])
			ItemList.setArt({'icon':item[1],'thumb':item[1]})
			ItemList.setProperty('description',item[2])
			ItemList.setProperty('mode','tools')
			ItemList.setProperty('submode',str(item[3]))
			self.control_list.addItem(ItemList)

	def Tool_Action(self,submode):
		if submode == 0:
			r = open(LOGFILE)
			text = r.read()
			import dialog_text
			d = dialog_text.Text_Viewer('Log Viewer',text,self.COLOR)
			d.doModal()
			del d
		elif submode == 1:
			self.setControlText(5001,'Attempting to backup user settings')
			CreateDir(backup_folder)
			filename = '{}_settings.xml'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
			CopyFile(USER_SETTINGS_XML,os.path.join(backup_folder,filename))
			XbmcSleep(500)
			if PathExists(os.path.join(backup_folder,filename)):
				Log('settings xml back up created {}'.format(filename))
				self.setControlText(5001,'settings xml back up created {}'.format(filename))
			else:
				Log('settings back up not created {}'.format(filename))
				self.setControlText(5001,'Unable to create settings backup')
		elif submode == 2:
			if PathExists(backup_folder):
				il = list()
				if len(os.listdir(backup_folder)) > 0:
					for file in os.listdir(backup_folder):
						if FnMatch(file, '*_settings.xml'):
							cdt = file.split('_',1)[0]
							item = xbmcgui.ListItem(label=DateTimeStrf(DateTimeObject(cdt),'%Y-%m-%d %H:%M'))
							item.setPath(os.path.join(backup_folder,file))
							item.setArt({'icon':AddonInfo('plugin.video.universemedia','icon')})
							il.append(item)
					import dialog_list
					d = dialog_list.Dialog_List(label='Select settings Backup(by Date)',buttons=('close',),color=self.COLOR,itemlist=il)
					d.doModal()
					pos = int(d.SELPOS)
					path = il[pos].getPath()
					CopyFile(path,USER_SETTINGS_XML)
				else:
					import dialog_action
					d=dialog_action.Dialog_Action(label='Please Action',msg='No backups created would you like to create?',buttons=('yes','no'),color=self.COLOR)
					d.doModal()
					if d.button_yes:
						self.Tool_Action(1)
			else:
				import dialog_action
				d=dialog_action.Dialog_Action(label='Please Action',msg='No backups created would you like to create?',buttons=('yes','no'),color=self.COLOR)
				d.doModal()
				if d.button_yes:
					self.Tool_Action(1)
		elif submode == 3:
			msg = ''
			for t in ['host','port']:
				s=str('service.'+t)
				d=SettingDefault(s)
				msg += 'Resetting {} to default\n'.format(s)
				self.setControlText(5001,msg)
				Log('{} {}'.format(s,d))
				setting_set(s,d)
		elif submode == 4:
			msg = ''
			ret = self.dialog.browse(0, heading='Select destination to save log files',shares='files',defaultt='')
			logfilename = '{}_kodi.log'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
			oldlogfilename = '{}_kodi.old.log'.format(DateTimeStrf(DateTimeNow(),'%Y%m%d%H%M'))
			Log(ret)
			if ret:
				CopyFile(LOGFILE,os.path.join(ret,logfilename))
				CopyFile(LOGFILE_OLD,os.path.join(ret,oldlogfilename))
				XbmcSleep(500)
				if os.path.isfile(os.path.join(ret,logfilename)):
					msg += 'Log file copied\n'
					self.setControlText(5001,msg)
				if os.path.isfile(os.path.join(ret,oldlogfilename)):
					msg += 'old.Log file copied\n'
					self.setControlText(5001,msg)
		elif submode == 5:
			l=list()
			tree = ET.parse(FAVOURITES)
			favourites = tree.getroot()
			for favourite in favourites:
				if addon_id in favourite.text or any(x in favourite.text for x in self.ServerList):
					itemList = xbmcgui.ListItem(label=favourite.get('name'),path=favourite.text)
					itemList.setArt({'icon':favourite.get('thumb')})
					l.append(itemList)
			import dialog_list
			d = dialog_list.Dialog_List(label='Select Favourite to modify/Remove',buttons=('close',),color=self.COLOR,itemlist=l)
			d.doModal()
			pos = int(d.SELPOS)
			sel_path =l[pos].getPath()
			sel_label = l[pos].getLabel()
			sel_icon = l[pos].getArt('icon')
			if pos != -1:
				dd = dialog_list.Dialog_List(label='modification of Favourite required',buttons=('close',),color=self.COLOR,itemlist=['Remove','Rename'])
				dd.doModal()
				posA = int(dd.SELPOS)
				if posA==0:
					for favourite in favourites:
						if favourite.text == sel_path:
							favourites.remove(favourite)
							tree.write(FAVOURITES)
				elif posA==1:
					ret3=KeyBoard('Edit label',default=sel_label)
					for favourite in favourites:
						if favourite.text == sel_path:
							favourite.set('name',ret3)
							tree.write(FAVOURITES)
				else:
					Log('modification selection not recognised')
			else:
				Log('Select Favourite to modify/Remove cancelled')
			del d
			del dd
		elif submode == 6:
			if PathExists(SETTINGS_XML):
				xbmcvfs.delete(SETTINGS_XML)
				XbmcSleep(500)
				if not PathExists(SETTINGS_XML):
					self.setControlText(5001,'settings.xml removed please restart addon')
					xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
				else:
					self.setControlText(5001,'Unable to delete settings.xml')
			else:
				self.setControlText(5001,'settings.xml dose not excist please restart addon')
				xbmc.executebuiltin('XBMC.ActivateWindow(Home)')


	def Maintenance_Action(self,submode):
		if submode == 0:
			self.setControlText(5001,'Attempting to delete EPG folder {}'.format(epg_folder))
			DelAllContents(epg_folder)
			XbmcSleep(500)
			if not PathExists(epg_folder):
				self.setControlText(5001,'EPG folder {} has been deleted'.format(epg_folder))
				if int(setting('getepgdata')) == 0:
					import dialog_action
					d=dialog_action.Dialog_Action(label='Please Action',msg='Settings indicate that Kodi is required to restart to re-write EPG Data, Do You wish to Close?',buttons=('yes','no'),color=self.COLOR)
					d.doModal()
					if d.button_yes:
						xbmc.executebuiltin('Quit')
					del d 
			else:
				self.setControlText(5001,'Unable to delete EPG folder')
		elif submode == 1:
			self.setControlText(5001,'Clearing AutoPlays from EPG')
			XbmcSleep(500)
			self.setControlText(5001,self.ClearAlarmList('autoplays'))
			self.Reset(5001)
			self.setFocusId(self.BUTTON_MAINTENANCE)
		elif submode == 2:
			self.setControlText(5001,'Clearing Reminders from EPG')
			XbmcSleep(500)
			self.setControlText(5001,self.ClearAlarmList('notifications'))
			self.Reset(5001)
			self.setFocusId(self.BUTTON_MAINTENANCE)
		elif submode == 3:
			self.setControlText(5001,'Clearing user settings Backups')
			XbmcSleep(500)
			DelAllContents(backup_folder)
			XbmcSleep(500)
			if not PathExists(backup_folder):
				self.setControlText(5001,'All user settings Backups cleared')
			else:
				self.setControlText(5001,'Unable to clear settings backups')
			self.Reset(5001)
		elif submode == 4:
			il = list()
			a = list()
			b = list()
			itemList = xbmcgui.ListItem(label='All db Cache tables')
			itemList.setArt({'icon':AddonInfo(addon_id,'icon')})
			itemList.setProperty('mode',str(0))
			il.append(itemList)
			tables = dbTableNames(DATABASE)
			for t in tables:
				itemList = xbmcgui.ListItem(label=t[0])
				itemList.setArt({'icon':AddonInfo(addon_id,'icon')})
				itemList.setProperty('mode',str(1))
				il.append(itemList)
			import dialog_list
			d = dialog_list.Dialog_List(label='Select Cache to Clear',buttons=('close',),color=self.COLOR,itemlist=il)
			d.doModal()
			pos = int(d.SELPOS)
			sel_mode = int(il[pos].getProperty('mode'))
			if sel_mode == 0:
				for table in tables:
					Log(table)
					Log(table[0])
					self.setControlText(5001,'Attempting to clear {} db cache'.format(table[0]))
					self.Reset(5001)
					dbDropTable(DATABASE,table[0])
					XbmcSleep(500)
					if not dbTableExists(DATABASE,table[0]):
						a.append(table)
					else:
						b.append(table)
				if len(tables) == len(a):
					self.setControlText(5001,'All cache db tables cleared')
				else:
					self.setControlText(5001,'Cache db tables cleared '+(','.join(a))+' Unable to Clear'+(','.join(b)))
			elif sel_mode == 1:
				ref = il[pos].getLabel()
				self.setControlText(5001,'Attempting to clear {} db cache'.format(ref))
				dbDropTable(DATABASE,ref)
				self.Reset(5001)
				XbmcSleep(500)
				if not dbTableExists(DATABASE,ref):
					self.setControlText(5001,'Cleared {} db cache'.format(ref))
				else:
					self.setControlText(5001,'Unable to clear {} db cache'.format(ref))
			del d



	def Maintenance_Menu(self):
		self.Reset(4003)
		self.setControlText(4003,'')
		#items title,icon,info,action,additional info 
		items = [('Clear All EPG Data',addon_icon,'Clear all cached data for all EPGS',0),('Clear AutoPlay',addon_icon,'Clear all AutoPlay actions from EPG\nSet AutoPlays\n'+self.ReadAlarmList('autoplay'),1),('Clear Reminders',addon_icon,'Clear all Reminders for EPG\nSet Reminders\n'+self.ReadAlarmList('remiders'),2),('Clear settings Backups',addon_icon,'Clear all settings.xml back up files created',3),('Clear Cache',addon_icon,'Clear Cached data that is used to speed up loading and running of addon',4)]
		self.control_list = self.getControl(2000)
		self.control_list.reset()
		for item in items:
			ItemList = xbmcgui.ListItem(item[0])
			ItemList.setArt({'icon':item[1],'thumb':item[1]})
			ItemList.setProperty('description',item[2])
			ItemList.setProperty('mode','maintenance')
			ItemList.setProperty('submode',str(item[3]))
			self.control_list.addItem(ItemList)


	def Extinfo_Action(self,submode):
		if submode == 1:
			self.setControlText(5001,'Attempting to push settings')
			if HasAddon('script.extendedinfo'):
				self.setting_set_ext('tmdb_username',setting('tmdbuser'))
				self.setting_set_ext('tmdb_password',setting('tmdbpassword'))
				self.setting_set_ext('include_adults',setting('tmdbadult'))
				Sleep(5)
				self.Reset(5001)
				if setting('tmdbuser')==self.setting_ext('tmdb_username') and setting('tmdbpassword')==self.setting_ext('tmdb_password') and setting('tmdbadult')==self.setting_ext('include_adults'):
					self.setControlText(5001,'Settings pushed correctly')
					Log('Settings pushed from KM to EXT INFO correctly')
				else:
					self.setControlText(5001,'Settings Not Pushed correctly')
					Log('Settings not pushed from KM to EXT INFO correctly')
			else:
				self.setControlText(5001,'Extened Info not installed please install')
				Log('attemping to push settings from KM extended info script.extendedinfo not installed')
			self.Reset(5001)
		elif submode == 2:
			self.setControlText(5001,'Checking if Extened Info Addon is installed')
			XbmcSleep(500)
			self.Reset(5001)
			if HasAddon('script.extendedinfo'):
				self.setControlText(5001,'Extened Info Addon is already installed')
			else:
				InstallAddon('script.extendedinfo')
			self.Reset(5001)

		elif submode == 3:
			if HasAddon('script.extendedinfo'):
				self.setControlText(5001,'Opening settings for Extened Info')
				XbmcSleep(500)
				OpenSettings(addonID='script.extendedinfo')
			else:
				self.setControlText(5001,'Extened Info not installed please install') 
			self.Reset(5001)


	def Extinfo_Menu(self):
		self.Reset(4003)
		#items title,icon,info,action
		if HasAddon('script.extendedinfo'):
			icon = AddonInfo('script.extendedinfo','icon')
			text = '[COLOR green]script.extendedinfo addon is installed[/COLOR]'
		else:
			icon = addon_icon
			text = '[COLOR red]script.extendedinfo addon is not installed[/COLOR]'
		items = [('Install',icon,'Install script.extendedinfo, Addon is used in EPG and VOD for extra info on Movies and TV shows',2),('Push settings',icon,'Push settings from Universe media addon settings to extendedinfo settings',1),('Settings',icon,'Open Extened Info  settings',3)]
		self.control_list = self.getControl(2000)
		self.control_list.reset()
		for item in items:
			ItemList = xbmcgui.ListItem(item[0])
			ItemList.setArt({'icon':item[1],'thumb':item[1]})
			ItemList.setProperty('description',item[2])
			ItemList.setProperty('mode','extendedinfo')
			ItemList.setProperty('submode',str(item[3]))
			self.control_list.addItem(ItemList)
		self.setControlText(controlId=4003,text=text)

	def Epg_Action(self,submode,listitems):
		submode = int(submode)
		if submode == 1:
			country = listitems.getProperty('country')
			from resources.lib.modules import panelcalls
			panelcalls.GetXmlTv()
			epg_folder = eval('{}_epg_folder'.format(country.lower()))
			CreateDir(epg_folder)
			XbmcSleep(500)
			if PathExists(EPG_XML):
				Log('{} EPG File Retrieved'.format(country.upper()))
				self.setControlText(5001,'{} EPG File Retrieved'.format(country.upper()))
				self.CustomXMLTV(country)
				XbmcSleep(500)
				if PathExists(eval('{}_EPG_XML'.format(country.upper()))):
					self.setControlText(5001,'Custom EPG created for {} '.format(country.upper()))
					xbmcvfs.delete(eval('{}_SOURCE_DB'.format(country.upper())))
					xbmcvfs.delete(os.path.join(eval('{}_epg_folder'.format(country.lower())),'xmltv.xml'))
					self.Epg_Menu()
				else:
					self.setControlText(5001,'Custom EPG not created for {}'.format(country.upper()))
			else:
				self.setControlText(5001,'{} EPG File not Retrieved'.format(country.upper()))

	def Epg_Menu(self):
		self.Reset(4003)
		self.Reset(5001)
		self.setControlText(5001,'')
		self.setControlText(4003,'')
		self.control_list = self.getControl(2000)
		self.control_list.reset()
		for Epg in self.MyEpgList:
			C = Epg.lower().replace('epg','').strip()
			description = 'Main service file\n  {dta}\n {c} file\n  {dtb}\n{c} file guide\n  {dtc}\n {c} database\n  {dtd}'.format(
				dta=FileMod_dt(EPG_XML).replace(microsecond=0),
				c=C.upper(),
				dtb=FileMod_dt(eval('{}_EPG_XML'.format(C.upper()))).replace(microsecond=0),
				dtc=FileMod_dt(os.path.join(eval('{}_epg_folder'.format(C)),'xmltv.xml')).replace(microsecond=0),
				dtd=FileMod_dt(eval('{}_SOURCE_DB'.format(C.upper()))).replace(microsecond=0)) 
			ItemList = xbmcgui.ListItem('Update {} EPG'.format(C.upper()))
			ItemList.setArt({'icon':addon_icon,'thumb':addon_icon})
			ItemList.setProperty('mode','epg')
			ItemList.setProperty('submode','1')
			ItemList.setProperty('country',C)
			ItemList.setProperty('description',description)
			self.control_list.addItem(ItemList)

	def MyEpgList(self):
		i = list()
		for Epg in self.Epgs:
			if setting_true('{}'.format(Epg)):
				i.append(Epg)
		return i 

	def CustomXMLTV(self,epg_country):
		streamMatch = list()
		buildxml = False
		dupid = list()
		progToremove = list()
		toRemove = list()
		chllist = list()
		from resources.lib.modules import panelcalls
		livelist,livelistcount = panelcalls.GetEpgChannels(channeltype='live')
		if xbmcvfs.exists(EPG_XML):
			f = FileWrapper(EPG_XML)
			tree = ET.parse(f)
			root = tree.getroot()
			for channels in root.findall('channel'):
				streamElem = ET.Element('stream')
				channels.append(streamElem)
				channel = channels.find('display-name')
				channeltext = channels.findtext('display-name')
				Id = channels.get('id')
				toRemove.append(channels)
				if channeltext.lower().startswith('{}:'.format(epg_country.lower())) or Id.lower().endswith('.{}'.format(epg_country.lower())) and Id not in dupid and len((filter(lambda channel: channel['epg_channel_id'] == Id, livelist)))>0:
					streamId = filter(lambda channel:channel['epg_channel_id'] == Id,livelist)[0]['streamid']
					Match = filter(lambda channel:channel['epg_channel_id'] == Id,livelist)
					playUrl = '{}/live/{}/{}/{}.ts'.format(panelcalls.GetHostPort(),setting('service.username'),setting('service.password'),streamId)
					dupid.append(Id)
					if channels in toRemove:
						toRemove.remove(channels)
					if not Id in progToremove:
						progToremove.append(Id)
					new_displayname = self.clean_channelName(channeltext)
					channel.text = new_displayname
					streamElem.text = playUrl
					for items in Match:
						streamMatch.append(items)
			for chl in toRemove:
				root.remove(chl)
			for programmes in root.findall('programme'):
				if not programmes.get('channel') in progToremove:
					root.remove(programmes)
			tree.write(eval('{}_EPG_XML'.format(epg_country.upper())),encoding='utf-8')

	def clean_channelName(self,name):
		if len(name)>3:
			if name[2] == ':':
				name = name[3:]
		if name.lower().replace(' ','').startswith('ukvip'):
			name = name.replace('UK VIP','')
		if name.lower().endswith(('sd','fhd','fhd*','hd')):
			name = name.rsplit(' ', 1)[0]
		return name.strip()

	def ClearAlarmList(self,table):
		PATHS = list()
		empDB = 0
		#Clears all alarms and list from table
		for e in self.MyEpgList:
			e = e[3:].upper()
			path = eval('{}_SOURCE_DB'.format(e))
			if PathExists(path):
				PATHS.append(path)
				rows = dbReadRows(path,table)
				if len(rows) > 0:
					for row in rows:
						alarm_name = self.createAlarmClockName(row[1],row[3])
						xbmc.executebuiltin('CancelAlarm({}-start,True)'.format(alarm_name.encode('utf-8', 'replace')))
						xbmc.executebuiltin('CancelAlarm({}-stop,True)'.format(alarm_name.encode('utf-8', 'replace')))
						Log('{} Alarm cancelled'.format(alarm_name))
				dbDeleteTableContent(path,table)
		for PATH in PATHS:
			empDB += len(dbReadRows(PATH,table))
		if empDB == 0:
			message='{} Alarms & Lists cleared'.format(table.capitalize())
			Log('{} Alarms & Lists cleared'.format(table.capitalize()))
		else:
			Log('{} Alarms & Lists NOT cleared'.format(table.capitalize()))
			message = '{} Alarms & Lists NOT cleared'.format(table.capitalize())
		return message

	def ReadAlarmList(self,table):
		tl = list()
		PATHS = list()
		if table == 'autoplay':
			table = 'autoplays'
		elif table == 'remiders':
			table = 'notifications'
		for e in self.MyEpgList:
			e = e[3:].upper()
			path = eval('{}_SOURCE_DB'.format(e))
			if PathExists(path):
				PATHS.append(path)
				rows = dbReadRows(path,table)
				if len(rows) > 0:
					for row in rows:
						p = row[1]
						dt = FromTimeStamp(row[3])
						line = '{} {}'.format(p,dt)
						tl.append(line)
		text = '\n'.join(tl)
		return text 



	def createAlarmClockName(self, programTitle, startTime):
		return 'universemedia-{}-{}'.format(programTitle, startTime)



class FileWrapper(object):
	def __init__(self, filename):
		self.vfsfile = xbmcvfs.File(filename,"rb")
		self.size = self.vfsfile.size()
		self.bytesRead = 0

	def close(self):
		self.vfsfile.close()

	def read(self, byteCount):
		self.bytesRead += byteCount
		return self.vfsfile.read(byteCount)

	def tell(self):
		return self.bytesRead
