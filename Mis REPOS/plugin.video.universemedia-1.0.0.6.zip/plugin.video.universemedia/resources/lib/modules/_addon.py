import os
import xbmc
import xbmcaddon

addon           = xbmcaddon.Addon()
addoninfo       = addon.getAddonInfo
setting         = addon.getSetting
setting_true    = lambda x: bool(True if setting(str(x)) == "true" else False)
setting_set     = addon.setSetting
local_str       = addon.getLocalizedString
has_addon       = lambda x: xbmc.getCondVisibility("System.HasAddon({addon})".format(addon=str(x)))



addon_version   = addoninfo('version')
addon_name      = addoninfo('name')
addon_id        = addoninfo('id')
addon_icon      = addoninfo("icon")
addon_fanart    = addoninfo("fanart")
addon_path      = xbmc.translatePath(addoninfo('path').decode('utf-8'))
addon_profile   = xbmc.translatePath(addoninfo('profile').decode('utf-8'))

#XBMC PATHS
HOME_FOLDER = xbmc.translatePath('special://home')
USERDATA = xbmc.translatePath('special://userdata').decode('utf-8')
LOGPATH     = xbmc.translatePath('special://logpath')
FAVOURITES = os.path.join(USERDATA,'favourites.xml')
LOGFILE     = os.path.join(LOGPATH,'kodi.log')
LOGFILE_OLD = os.path.join(LOGPATH,'kodi.old.log')

#FOLDER PATHS
resources_folder = os.path.join(addon_path,'resources')
skin_folder      = os.path.join(resources_folder,'skins')
Default_folder   = os.path.join(skin_folder,'Default')
media_folder     = os.path.join(Default_folder,'media')
icon_folder      = os.path.join(media_folder,'icon')
epg_folder       = os.path.join(addon_profile,'epg')
uk_epg_folder    = os.path.join(epg_folder,'uk_epg')
us_epg_folder    = os.path.join(epg_folder,'us_epg')
es_epg_folder    = os.path.join(epg_folder,'es_epg')
de_epg_folder    = os.path.join(epg_folder,'de_epg')
my_epg_folder    = os.path.join(epg_folder,'my_epg')
hk_epg_folder    = os.path.join(epg_folder,'hk_epg')
backup_folder    = os.path.join(addon_profile,'backup')
settings_folder  = os.path.join(resources_folder,'settings')





#FILE PATHS
actionsjs         = os.path.join(resources_folder,'actions.json')
profile_actionsjs = os.path.join(addon_profile,'actions.json')
UK_EPG_XML        = os.path.join(uk_epg_folder,'UK_guide.xml')
US_EPG_XML        = os.path.join(us_epg_folder,'US_guide.xml')
ES_EPG_XML        = os.path.join(es_epg_folder,'ES_guide.xml')
DE_EPG_XML        = os.path.join(de_epg_folder,'DE_guide.xml')
MY_EPG_XML        = os.path.join(my_epg_folder,'MY_guide.xml')
HK_EPG_XML        = os.path.join(hk_epg_folder,'HK_guide.xml')
UK_SOURCE_DB      = os.path.join(uk_epg_folder,'source.db')
US_SOURCE_DB      = os.path.join(us_epg_folder,'source.db')
ES_SOURCE_DB      = os.path.join(es_epg_folder,'source.db')
DE_SOURCE_DB      = os.path.join(de_epg_folder,'source.db')
MY_SOURCE_DB      = os.path.join(my_epg_folder,'source.db')
HK_SOURCE_DB      = os.path.join(hk_epg_folder,'source.db')
UK_CATC           = os.path.join(uk_epg_folder,'uk_category_count.ini')
US_CATC           = os.path.join(us_epg_folder,'us_category_count.ini')
ES_CATC           = os.path.join(es_epg_folder,'es_category_count.ini')
DE_CATC           = os.path.join(de_epg_folder,'de_category_count.ini')
HK_CATC           = os.path.join(hk_epg_folder,'hk_category_count.ini')
MY_CATC           = os.path.join(my_epg_folder,'my_category_count.ini')
UK_CAT            = os.path.join(uk_epg_folder,'uk_categories.ini')
US_CAT            = os.path.join(us_epg_folder,'us_categories.ini')
ES_CAT            = os.path.join(es_epg_folder,'es_caterories.ini')
DE_CAT            = os.path.join(de_epg_folder,'de_caterories.ini')
MY_CAT            = os.path.join(my_epg_folder,'my_caterories.ini')
HK_CAT            = os.path.join(hk_epg_folder,'hk_caterories.ini')
DATABASE          = os.path.join(addon_profile,'data.db')
EPG_XML           = os.path.join(epg_folder,'xmltv.xml')
USER_SETTINGS_XML = os.path.join(addon_profile,'settings.xml')
SETTINGS_XML      = os.path.join(resources_folder,'settings.xml')
SETTINGS_XML_18   = os.path.join(settings_folder,'settings_18.xml')
SETTINGS_XML_17   = os.path.join(settings_folder,'settings_17.xml')


#VARIABLES
DSPL_country_replace = {'United Kingdom':'UK','Spain':'ES','United States':'US','Italy':'IT','Germany':'DE','France':'FR','India':'IN',                    'China':'CN','Portugal':'PT','Singapore':'SG','Netherlands':'NL','Canada':'CA','Thailand':'TH','Hong kong':'HK',                    'Malaysia':'MY','United Arab Emirates':'AR','Indonesia':'ID','Serbia':'SR'}
epg_short_long_name  = {'UK':'United Kingdom','ES':'Spain','US':'United States','DE':'Germany','HK':'Hong Kong','MY':'Malaysia'}
Channel_name_clean   = {' FHD':'',' SD':'','1080P':'','1080p':'',' HD':''}
country_ignore       = ['Zimbabwe','Zambia','Uganda','Tanzania','Sao Tome And Principe','Saint Kitts and Nevis','Saint Lucia',                    'Saint Vincent and the Grenadines','Seychelles','Nigeria','Niger','Montserrat','Liberia','Lesotho']
Available_Services   = [{'s':'gold','p':'xtream'},{'s':'red','p':'xtream'},{'s':'green','p':'xtream'},{'s':'ruby','p':'alltv'}]

