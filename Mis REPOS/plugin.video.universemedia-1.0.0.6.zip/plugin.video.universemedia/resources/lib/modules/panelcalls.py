# -*- coding: utf-8 -*-
import requests
import xbmcgui
from bs4 import BeautifulSoup
from resources.lib.modules._addon import *
from resources.lib.modules._common import *

pDialog = xbmcgui.DialogProgress()
guiDialog = xbmcgui.Dialog()



def CheckAccount():
	data = GetEpg()
	userinfo = data.get('user_info')
	auth = userinfo.get('auth')
	if int(auth) == 1:
		Log('Login Check OK')
		return True
	else:
		Log('Login Check Failed')
		return False

def GetEpg():
	base_url = GetHostPort()
	url = '{}/panel_api.php?username={}&password={}'.format(base_url,setting('service.username'),setting('service.password'))
	r = requests.get(url)
	data = r.json()
	return data

def GetEpgChannels(channeltype):
	livelist = []
	count = 0
	if dbReadCol(DATABASE,'subinfo','login') == 1:
		login = True
	elif CheckAccount():
		login = True
	else:
		login = False
	if login:
		data = GetEpg()
		channels = data.get("available_channels")
		for channel in channels:
			channeldata = data.get("available_channels").get(str(channel))
			if channeldata.get('stream_type') == channeltype:
				count += 1
				name= channeldata.get('name')
				streamid= channeldata.get("stream_id")
				category_name = channeldata.get('category_name')
				epg_channel_id =  channeldata.get('epg_channel_id')
				livelist.append({'name':name,'streamid':streamid,'category_name':category_name,'epg_channel_id':epg_channel_id})
	return livelist,count

def GetHostPort():
	host = setting('service.host')
	port = setting('service.port')
	return '{}:{}'.format(host,port)


def GetXmlTv():
	Log('Getting panel xmltv file for service')
	base_url = GetHostPort()
	url = '{}/xmltv.php?username={}&password={}'.format(base_url,setting('service.username'),setting('service.password'))
	DownloadFile(url,EPG_XML)


def GetLiveCat():
	livecat = []
	base_url = GetHostPort()
	url = '{}/enigma2.php?username={}&password={}&type=get_live_categories'.format(base_url,setting('service.username'),setting('service.password'))
	Log(url)
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	channels = soup('channel')
	for channel in channels:
		title = channel('title')
		list_url = channel('playlist_url')
		livecat.append((bsixfour(title[0].text),2,list_url[0].text))
	return livecat


def GetLiveList(title,url):
	livelist = []
	if AdultLock(title):
		html = requests.get(url).text
		soup = BeautifulSoup(html, 'html.parser')
		channels = soup('channel')
		for channel in channels:
			vodtitle = channel('title')
			description = channel('description')
			streamurl = channel('stream_url')
			name = bsixfour(vodtitle[0].text)
			if '[' in name and ']' in name:
				name = name.split('[',1)[0]
			livelist.append((name,streamurl[0].text,bsixfour(description[0].text)))
	return livelist

def AdultLock(name):
	if setting_true('plock'):
		tabo = ['adult','adults','porn','xxx','erotic','brazzers','hustler','redlight','red light','satisfaction']
		if any(s in name.lower() for s in tabo):
			plockcheck = KeyBoard(msg='Enter Code for parental lock')
			if str(plockcheck) == setting('plockcode'):
				return True
			else:
				return False
		else:
			return True
	else:
		return True

def GetVodCat():
	vodcat = [('Search On Demand',8,'')]
	base_url = GetHostPort()
	url = '{}/enigma2.php?username={}&password={}&type=get_vod_categories'.format(base_url,setting('service.username'),setting('service.password'))
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	channels = soup('channel')
	for channel in channels:
		title = channel('title')
		list_url = channel('playlist_url')
		vodcat.append((bsixfour(title[0].text),7,list_url[0].text))
	return vodcat


def GetVodList(title,url):
	dbCreateTableHeaders(DATABASE,'tmdb_movies','tmdb_id,title,poster_path,backdrop_path,overview,release_date,Genres')
	vodlist = []
	if AdultLock(title):
		html = requests.get(url).text
		soup = BeautifulSoup(html, 'html.parser')
		channels = soup('channel')
		percent = 100.00/len(channels)
		pDialog.create(heading='Collecting {} movies'.format(title) if not title.lower().endswith(('movie' ,'movies' )) else 'Collecting {}'.format(title))
		count = 0
		for channel in channels:
			iD = ''
			count +=1
			vodtitle = channel('title')
			pDialog.update(int(count*percent),'Adding {} ({} of {})'.format(bsixfour(vodtitle[0].text),count,len(channels)))
			icon = channel('desc_image')
			description = channel('description')
			streamurl = channel('stream_url')
			if setting_true('tmdbmeta'):
				from resources.lib.modules import tmdb_api
				description = bsixfour(description[0].text)
				if 'KINOPOISK_ID' in description:
					iDs = re.compile('KINOPOISK_ID:(.+?)\n').findall(str(description))
					if len(iDs)>0:
						iD = iDs[0].strip()
					else: iD = ''
				if 'TMDB_ID' in description and iD == '': 
					iDs = re.compile('TMDB_ID:(.+?)\n').findall(str(description))
					if len(iDs)>0:
						iD = iDs[0].strip()
					else: iD = ''
					Log(iD)
				if 'IMDB_ID' in description and iD == '':
					remove= re.compile(r'(\d\d\d\d)').findall(base64.b64decode(vodtitle[0].text))
					if len(remove)>0:
						cleantitle = (bsixfour(vodtitle[0].text)).replace(remove[0],'')
					else: cleantitle = bsixfour(vodtitle[0].text)
					cleantitle=cleantitle.replace('Bluray','').replace('Hdcam','').replace('HDCAM','').replace('CAM','').strip()
					Date = re.compile('RELEASEDATE:(.+?)\n').findall(description)
					try:
						Year = dparser.parse(Date[0],fuzzy=True).strftime('%Y')
					except ValueError:
						if len(remove) > 0:
							Year = remove[0]
						else:
							Year = None
					if Year != None:
						iD = str(tmdb_api.SearchMovie(cleantitle,Year))
					else:
						iD = ''
				if iD.isdigit():
					if not dbIsInTable(DATABASE,'tmdb_movies','tmdb_id',iD):
							title,poster_path,backdrop_path,overview,release_date,Genres = tmdb_api.MovieMetaData(iD)
							Genres = ','.join(Genres)
							dbWrite(DATABASE,'tmdb_movies',(iD,title,poster_path,backdrop_path,overview,release_date,Genres))
					if dbIsInTable(DATABASE,'tmdb_movies','tmdb_id',iD):
						match = dbReadMatch(DATABASE,'tmdb_movies','tmdb_id',iD)
						vodlist.append((match[1].encode('utf8','ignore'),streamurl[0].text,3,match[2],match[3],match[4].encode('utf8','ignore'),match[5],match[6],iD))
				else:
					vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,3,icon[0].text,'','','','','',''))
			else:
				vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,3,icon[0].text,'','','','','',''))
		pDialog.close()
		return vodlist

def GetSearchVodList():
	vodlist = []
	query = KeyBoard(msg='')
	base_url = GetHostPort()
	url = '{}/enigma2.php?username={}&password={}&type=get_vod_categories'.format(base_url,setting('service.username'),setting('service.password'))
	playlistUrl = []
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	if soup.find_all('playlist_url'):
		channels = soup('channel')
		for channel in channels:
			playlist = channel('playlist_url')
			playlistUrl.append( playlist[0].text)
	totalpage = len(playlistUrl)
	percent = int(100.00/totalpage)
	pagecount = 0
	matchitems = 0
	titlematch = []
	pDialog.create(heading='Searching for \"{}\"'.format(query))
	for url in playlistUrl:
		pagecount += 1
		pDialog.update(percent*pagecount,'Searching page {} of {} matches found {}'.format(pagecount,totalpage,matchitems))
		html2 = requests.get(url).text
		soup2 = BeautifulSoup(html2,'html.parser')
		if soup2.find_all('stream_url'):
			channels = soup2('channel')
			for channel in channels:
				iD = ''
				title = channel('title')
				title = base64.b64decode(title[0].text)
				if query.lower() in title.lower():
					if title not in titlematch:
						titlematch.append(title)
						matchitems += 1
						pDialog.update(percent*pagecount,'Searching page {} of {} matches found {}'.format(pagecount,totalpage,matchitems))
						streamurl = channel('stream_url')
						icon = channel('desc_image')
						description = channel('description')
						if setting_true('tmdbmeta'):
							from resources.lib.modules import tmdb_api
							description = bsixfour(description[0].text)
							if 'KINOPOISK_ID' in description:
								iDs = re.compile('KINOPOISK_ID:(.+?)\n').findall(str(description))
								if len(iDs)>0:
									iD = iDs[0].strip()
								else: iD = ''
							if 'TMDB_ID' in description and iD == '': 
								iDs = re.compile('TMDB_ID:(.+?)\n').findall(str(description))
								if len(iDs)>0:
									iD = iDs[0].strip()
								else: iD = ''
								Log(iD)
							if 'IMDB_ID' in description and iD == '':
								remove= re.compile('(\d\d\d\d)').findall(str(title))
								cleantitle = title.replace(remove[0],'').replace('Bluray','').replace('Hdcam','').replace('HDCAM','').replace('CAM','').strip()
								Date = re.compile('RELEASEDATE:(.+?)\n').findall(description)
								try:
									Year = dparser.parse(Date[0],fuzzy=True).strftime('%Y')
								except ValueError:
									if len(remove) > 0:
										Year = remove[0]
									else:
										Year = None
								if Year != None:
									iD = str(tmdb_api.SearchMovie(cleantitle,Year))
								else:
									iD = ''
							if iD.isdigit():
								if not dbIsInTable(DATABASE,'tmdb_movies','tmdb_id',iD):
									title,poster_path,backdrop_path,overview,release_date,Genres = tmdb_api.MovieMetaData(iD)
									Genres = ','.join(Genres)
									dbWrite(DATABASE,'tmdb_movies',(iD,title,poster_path,backdrop_path,overview,release_date,Genres))
								if dbIsInTable(DATABASE,'tmdb_movies','tmdb_id',iD):
									match = dbReadMatch(DATABASE,'tmdb_movies','tmdb_id',iD)
									vodlist.append((match[1].encode('utf8','ignore'),streamurl[0].text,3,match[2],match[3],match[4].encode('utf8','ignore'),match[5],match[6],iD))
							else:
								vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,3,icon[0].text,'','','','','',''))
						else:
							vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,3,icon[0].text,'','','','','',''))
		pDialog.close()
		return vodlist