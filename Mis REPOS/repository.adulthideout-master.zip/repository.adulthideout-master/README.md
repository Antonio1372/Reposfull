# AdultHideout
XXX Porn Adult Addon for Kodi.<br />
The one and only official site for my Repo is this Github Page.<br />
If you find my Repo somewhere else, he/she has nothing to do with me. 

# What it is
Adulthideout is my first try to make a Kodi XXX Addon. This addon was actually made for one Page to add the "play from here" function that is missing in nearly all similiar addons, but somehow turned into something bigger. 
# FAQ
Q: How can i remove the Pin?<br />
A: There is no Pin or Password protection in Adulthideout and there never will be.<br />
You are not using original Kodi and/or original AdultHideout.<br />
Most of the time Kodi bundles or addon bundles are the Problem.

Just deinstall Kodi and reinstall it from it's original source https://kodi.tv/download and follow the intructions on this Page to install AdultHideot. Password gone!

Q: Can you add site [addSitenamehere] to AdultHideout?<br />
A: No! There are 30 Sites in Adulthideout and little bit of everything for anyone. AND it's very hard to keep those sites runnig. If we have to remove a Site...maybe.

Q: Is there a develop version of Adulthideout on github?<br />
A: No, not really. But i upload my beta test Version always to http://ah.net76.net/addons/ with fixes before releasing Adulthideout.

    
# Installation for Kodi 16
1. Download Repo https://github.com/Vashiel/repository.adulthideout/releases/download/Repo/repository.adulthideout-1.0.1.zip
2. Start Kodi
3. Goto "system> addons> install from zip" and choose the downloaded Repo zip file.
4. Wait for message repo has been installed
5. Go to addons and choose install from repo (or "get more" on older versions of Kodi)
6. Choose adult hideout and click video, then adult hideout
7. Wait till adulthideout has been installed . 
8. You will find Adulthideout now under "Video - Addons"
9. Have Fun :)

#Video installation instructions on Youtube
For those who still have problems with the installation, i just uploaded Intructions on Youtube. Link below.
https://youtu.be/R8kcLXioEP0

# NEW!!! Installation for Kodi 17 or higher with Estuary skin
#New instalattion tutorial on youtube.

If you can't copy the repo zip file to your Kodi Device, here is a alternative way to install AdultHideout.
https://youtu.be/bFuwYpAcOXE

# Contact me
Easy way is to write me via Github or adulthideout@yandex.com (don't check that one very often)